"""
TTS 加速器 配置与测试 GUI
功能：
  - 角色管理（增删改、语言/cut方法/语速配置）
  - 服务器管理（增删改、拖拽排序、在线检测）
  - 全局设置（生成路径、并行触发阈值）
  - 配置导入/导出（JSON）
  - 测试播放（实时日志）
  - 兼容 Windows / Linux 路径
"""

import sys, os, re, io, json, wave, threading, platform, subprocess, shutil
import urllib.request, urllib.error
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

# ── 平台 ──────────────────────────────────────────────────
IS_WIN = platform.system() == "Windows"

# ── 默认配置 ─────────────────────────────────────────────
DEFAULT_CONFIG = {
    "version": "2.0",
    "audio_dir": r"G:\WorkBuddy\generated_audio" if IS_WIN else "/home/terrence/Desktop/openclaw/generated_audio",
    "parallel_threshold": 2,          # 句数 >= 此值时触发并行
    "server_groups": [
        {
            "name": "笔记本（首选）",
            "urls": [
                "http://192.168.28.3:9880/tts",
                "http://192.168.31.5:9880/tts",
                "http://192.168.28.7:9880/tts",
            ]
        },
        {
            "name": "华硕主机（备选）",
            "urls": [
                "http://192.168.31.177:9880/tts",
                "http://192.168.28.2:9880/tts",
                "http://192.168.28.127:9880/tts",
            ]
        }
    ],
    "roles": {
        "可莉": {
            "ref_audio_path": "audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
            "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
            "prompt_lang": "zh",
            "text_lang": "zh",
            "text_split_method": "cut5",
            "speed_factor": 1.0,
        },
        "瑶瑶": {
            "ref_audio_path": "audio/yaoyao-甘雨姐姐，你没事吧？要不要喝点水，或者吃点别的什么调节一下？.wav",
            "prompt_text": "甘雨姐姐，你没事吧？要不要喝点水，或者吃点别的什么调节一下？",
            "prompt_lang": "zh",
            "text_lang": "auto",
            "text_split_method": "cut5",
            "speed_factor": 1.0,
        },
        "纳西妲": {
            "ref_audio_path": "audio/nahida-如果是说踏鞴砂那个神秘事件与倾奇者之类的.wav",
            "prompt_text": "如果是说踏鞴砂那个神秘事件与倾奇者之类的",
            "prompt_lang": "zh",
            "text_lang": "zh",
            "text_split_method": "cut5",
            "speed_factor": 0.85,
        },
    }
}

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tts_gui_config.json")

LANG_OPTIONS = [
    ("中文",   "zh"),
    ("英文",   "en"),
    ("日语",   "ja"),
    ("粤语",   "yue"),
    ("自动",   "auto"),
]
CUT_OPTIONS = [
    ("cut0 - 不切分",           "cut0"),
    ("cut1 - 按句号切",         "cut1"),
    ("cut2 - 每50字切一次",     "cut2"),
    ("cut3 - 按中文句号切",     "cut3"),
    ("cut4 - 按标点切（均衡）", "cut4"),
    ("cut5 - 按标点切（自然）", "cut5"),
]

# ════════════════════════════════════════════════════════
#  TTS 核心逻辑（独立于 GUI，可被脚本复用）
# ════════════════════════════════════════════════════════

def split_sentences(text):
    if not text.strip():
        return []
    parts = re.split(r'(?<=[。！？…～\!\?])', text)
    parts = [p.strip() for p in parts if p.strip()]
    merged = []
    buf = ""
    for p in parts:
        buf += p
        if len(buf) >= 8:
            merged.append(buf); buf = ""
    if buf:
        if merged:
            merged[-1] += buf
        else:
            merged.append(buf)
    result = []
    for s in merged:
        if len(s) > 50:
            subs = re.split(r'(?<=[，,；;、])', s)
            subs = [x.strip() for x in subs if x.strip()]
            sub_buf = ""
            for sub in subs:
                sub_buf += sub
                if len(sub_buf) >= 15:
                    result.append(sub_buf); sub_buf = ""
            if sub_buf:
                if result: result[-1] += sub_buf
                else: result.append(sub_buf)
        else:
            result.append(s)
    return result if result else [text]

def build_payload(role_cfg, text):
    return {
        "text": text,
        "text_lang": role_cfg.get("text_lang", "zh"),
        "ref_audio_path": role_cfg["ref_audio_path"],
        "prompt_text": role_cfg["prompt_text"],
        "prompt_lang": role_cfg["prompt_lang"],
        "top_k": 5, "top_p": 1, "temperature": 1,
        "text_split_method": role_cfg.get("text_split_method", "cut5"),
        "batch_size": 1, "batch_threshold": 0.75,
        "split_bucket": True, "return_fragment": False,
        "speed_factor": role_cfg.get("speed_factor", 1.0),
        "streaming_mode": False, "seed": -1,
        "parallel_infer": True, "repetition_penalty": 1.35,
        "aux_ref_audio_paths": []
    }

def request_tts(urls, payload, timeout=60):
    data = json.dumps(payload).encode("utf-8")
    for url in urls:
        try:
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
            r = urllib.request.urlopen(req, timeout=timeout)
            audio = r.read()
            if len(audio) > 100:
                return audio, url
        except urllib.error.HTTPError as e:
            pass
        except Exception:
            pass
    return None, None

def merge_wav_bytes(wav_list):
    if not wav_list: return None
    if len(wav_list) == 1: return wav_list[0]
    frames_list = []; params = None
    for wb in wav_list:
        try:
            with wave.open(io.BytesIO(wb), 'rb') as wf:
                if params is None: params = wf.getparams()
                frames_list.append(wf.readframes(wf.getnframes()))
        except: pass
    if not frames_list or params is None: return None
    out = io.BytesIO()
    with wave.open(out, 'wb') as wf:
        wf.setparams(params)
        for f in frames_list: wf.writeframes(f)
    return out.getvalue()

def play_wav(path):
    """跨平台播放 WAV"""
    if IS_WIN:
        import winsound
        winsound.PlaySound(path, winsound.SND_FILENAME)
    elif shutil.which("aplay"):
        subprocess.run(["aplay", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    elif shutil.which("paplay"):
        subprocess.run(["paplay", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        os.startfile(path) if hasattr(os, "startfile") else None

def check_server(url, timeout=5):
    try:
        req = urllib.request.Request(url, data=b'{}', headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=timeout)
        return True, "在线"
    except urllib.error.HTTPError as e:
        return True, f"在线 (HTTP {e.code})"
    except Exception as e:
        return False, f"离线 ({type(e).__name__})"

# ════════════════════════════════════════════════════════
#  配置加载/保存
# ════════════════════════════════════════════════════════

def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            # 合并缺失字段
            for k, v in DEFAULT_CONFIG.items():
                cfg.setdefault(k, v)
            return cfg
        except: pass
    import copy
    return copy.deepcopy(DEFAULT_CONFIG)

def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

# ════════════════════════════════════════════════════════
#  主 GUI
# ════════════════════════════════════════════════════════

class TTSConfigApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TTS 加速器 配置工具 v2.0")
        self.geometry("980x720")
        self.minsize(800, 600)
        self.configure(bg="#1e1e2e")
        self.cfg = load_config()
        self._build_style()
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ── 主题 ──────────────────────────────────────────
    def _build_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        BG   = "#1e1e2e"
        FG   = "#cdd6f4"
        SEL  = "#313244"
        ACC  = "#89b4fa"
        BTN  = "#313244"
        BTNF = "#cdd6f4"
        RED  = "#f38ba8"
        GRN  = "#a6e3a1"
        YEL  = "#f9e2af"

        style.configure(".",         background=BG, foreground=FG, font=("Microsoft YaHei UI", 10))
        style.configure("TFrame",    background=BG)
        style.configure("TLabel",    background=BG, foreground=FG)
        style.configure("TEntry",    fieldbackground=SEL, foreground=FG, insertcolor=FG, borderwidth=1)
        style.configure("TCombobox", fieldbackground=SEL, foreground=FG, selectbackground=SEL,
                        selectforeground=FG, arrowcolor=ACC)
        style.map("TCombobox", fieldbackground=[("readonly", SEL)], foreground=[("readonly", FG)])
        style.configure("TNotebook",        background=BG, borderwidth=0)
        style.configure("TNotebook.Tab",    background=BTN, foreground=BTNF, padding=[14,6],
                        font=("Microsoft YaHei UI", 10, "bold"))
        style.map("TNotebook.Tab",          background=[("selected", ACC)], foreground=[("selected", BG)])
        style.configure("TButton",          background=BTN, foreground=BTNF, padding=[10,5], borderwidth=0)
        style.map("TButton",                background=[("active", ACC)], foreground=[("active", BG)])
        style.configure("Accent.TButton",   background=ACC, foreground=BG, padding=[10,5], borderwidth=0,
                        font=("Microsoft YaHei UI", 10, "bold"))
        style.map("Accent.TButton",         background=[("active", "#74c7ec")])
        style.configure("Danger.TButton",   background=RED, foreground=BG, padding=[10,5], borderwidth=0)
        style.map("Danger.TButton",         background=[("active", "#eba0ac")])
        style.configure("Success.TButton",  background=GRN, foreground=BG, padding=[10,5], borderwidth=0)
        style.map("Success.TButton",        background=[("active", "#94e2d5")])
        style.configure("TLabelframe",      background=BG, foreground=ACC, bordercolor=SEL)
        style.configure("TLabelframe.Label",background=BG, foreground=ACC,
                        font=("Microsoft YaHei UI", 10, "bold"))
        style.configure("Treeview",         background=SEL, foreground=FG, fieldbackground=SEL,
                        rowheight=28, borderwidth=0)
        style.map("Treeview",               background=[("selected", ACC)], foreground=[("selected", BG)])
        style.configure("Treeview.Heading", background=BTN, foreground=ACC,
                        font=("Microsoft YaHei UI", 10, "bold"))
        style.configure("TScrollbar",       background=SEL, troughcolor=BG, arrowcolor=ACC)
        style.configure("TScale",           background=BG, troughcolor=SEL)
        style.configure("TSeparator",       background=SEL)

        self.colors = {"BG": BG, "FG": FG, "SEL": SEL, "ACC": ACC,
                       "RED": RED, "GRN": GRN, "YEL": YEL, "BTN": BTN}

    # ── 主布局 ────────────────────────────────────────
    def _build_ui(self):
        top = ttk.Frame(self); top.pack(fill="x", padx=12, pady=(10,0))
        ttk.Label(top, text="🎵 TTS 加速器 配置工具",
                  font=("Microsoft YaHei UI", 14, "bold"),
                  foreground=self.colors["ACC"]).pack(side="left")
        ttk.Button(top, text="💾 保存配置", style="Accent.TButton",
                   command=self._save).pack(side="right", padx=4)
        ttk.Button(top, text="📤 导出", command=self._export).pack(side="right", padx=4)
        ttk.Button(top, text="📥 导入", command=self._import).pack(side="right", padx=4)

        nb = ttk.Notebook(self); nb.pack(fill="both", expand=True, padx=12, pady=8)
        self.nb = nb

        self.tab_global  = ttk.Frame(nb); nb.add(self.tab_global,  text="⚙️  全局设置")
        self.tab_roles   = ttk.Frame(nb); nb.add(self.tab_roles,   text="🎭  角色管理")
        self.tab_servers = ttk.Frame(nb); nb.add(self.tab_servers, text="🖥️  服务器管理")
        self.tab_test    = ttk.Frame(nb); nb.add(self.tab_test,    text="▶️  测试播放")

        self._build_global_tab()
        self._build_roles_tab()
        self._build_servers_tab()
        self._build_test_tab()

    # ════════════════════════════════════════════════
    #  标签页：全局设置
    # ════════════════════════════════════════════════
    def _build_global_tab(self):
        f = self.tab_global
        pad = {"padx": 16, "pady": 8}

        lf = ttk.LabelFrame(f, text="生成路径 & 并行设置", padding=16)
        lf.pack(fill="x", padx=16, pady=16)

        ttk.Label(lf, text="音频输出目录：").grid(row=0, column=0, sticky="w", **pad)
        self.v_audio_dir = tk.StringVar(value=self.cfg.get("audio_dir", ""))
        e = ttk.Entry(lf, textvariable=self.v_audio_dir, width=52)
        e.grid(row=0, column=1, sticky="ew", **pad)
        ttk.Button(lf, text="浏览…", command=lambda: self._browse_dir(self.v_audio_dir)
                   ).grid(row=0, column=2, **pad)

        ttk.Label(lf, text="并行触发阈值（句数 ≥ N 时启用并行）：").grid(row=1, column=0, sticky="w", **pad)
        self.v_threshold = tk.IntVar(value=self.cfg.get("parallel_threshold", 4))
        sf = ttk.Frame(lf); sf.grid(row=1, column=1, sticky="w", **pad)
        ttk.Spinbox(sf, from_=1, to=20, textvariable=self.v_threshold, width=6,
                    font=("Microsoft YaHei UI", 11)).pack(side="left")
        ttk.Label(sf, text="  句（建议 3~5）", foreground="#6c7086").pack(side="left")
        lf.columnconfigure(1, weight=1)

        lf2 = ttk.LabelFrame(f, text="说明", padding=16)
        lf2.pack(fill="x", padx=16, pady=(0,16))
        tips = (
            "• 并行阈值：句数 < N 时串行（单机），≥ N 时并行（多机同时合成）\n"
            "• 生成路径支持 Windows 路径（G:\\...）和 Linux 路径（/home/...）\n"
            "• 配置导入/导出格式为 JSON，可在不同机器间迁移"
        )
        ttk.Label(lf2, text=tips, foreground="#6c7086", justify="left").pack(anchor="w")

    # ════════════════════════════════════════════════
    #  标签页：角色管理
    # ════════════════════════════════════════════════
    def _build_roles_tab(self):
        f = self.tab_roles
        left = ttk.Frame(f, width=180); left.pack(side="left", fill="y", padx=(12,0), pady=12)
        left.pack_propagate(False)

        ttk.Label(left, text="角色列表", font=("Microsoft YaHei UI", 10, "bold"),
                  foreground=self.colors["ACC"]).pack(pady=(0,6))

        lb_frame = ttk.Frame(left); lb_frame.pack(fill="both", expand=True)
        sb = ttk.Scrollbar(lb_frame); sb.pack(side="right", fill="y")
        self.role_listbox = tk.Listbox(lb_frame, yscrollcommand=sb.set,
                                        bg=self.colors["SEL"], fg=self.colors["FG"],
                                        selectbackground=self.colors["ACC"],
                                        selectforeground=self.colors["BG"],
                                        font=("Microsoft YaHei UI", 11),
                                        borderwidth=0, highlightthickness=0, activestyle="none")
        self.role_listbox.pack(fill="both", expand=True)
        sb.config(command=self.role_listbox.yview)
        self.role_listbox.bind("<<ListboxSelect>>", self._on_role_select)

        btn_row = ttk.Frame(left); btn_row.pack(fill="x", pady=6)
        ttk.Button(btn_row, text="＋ 新增", style="Success.TButton",
                   command=self._role_add).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(btn_row, text="✕ 删除", style="Danger.TButton",
                   command=self._role_delete).pack(side="left", expand=True, fill="x", padx=2)

        sep = ttk.Separator(f, orient="vertical"); sep.pack(side="left", fill="y", pady=12, padx=8)

        right = ttk.Frame(f); right.pack(side="left", fill="both", expand=True, padx=8, pady=12)
        self._build_role_detail(right)
        self._refresh_role_list()

    def _build_role_detail(self, parent):
        self.role_detail = parent
        lf = ttk.LabelFrame(parent, text="角色详情", padding=16)
        lf.pack(fill="both", expand=True)

        R = 0
        def row(label, widget_factory, **kw):
            nonlocal R
            ttk.Label(lf, text=label).grid(row=R, column=0, sticky="w", padx=8, pady=6)
            w = widget_factory(lf, **kw); w.grid(row=R, column=1, sticky="ew", padx=8, pady=6)
            R += 1; return w

        self.v_role_name   = tk.StringVar()
        self.v_ref_audio   = tk.StringVar()
        self.v_prompt_text = tk.StringVar()
        self.v_prompt_lang = tk.StringVar()
        self.v_text_lang   = tk.StringVar()
        self.v_cut_method  = tk.StringVar()
        self.v_speed       = tk.DoubleVar(value=1.0)

        row("角色名称：",   ttk.Entry, textvariable=self.v_role_name, width=36)
        # ref_audio 行（带浏览按钮）
        ttk.Label(lf, text="参考音频路径：").grid(row=R, column=0, sticky="w", padx=8, pady=6)
        rf = ttk.Frame(lf); rf.grid(row=R, column=1, sticky="ew", padx=8, pady=6)
        ttk.Entry(rf, textvariable=self.v_ref_audio, width=38).pack(side="left", fill="x", expand=True)
        ttk.Button(rf, text="…", width=3, command=lambda: self._browse_file(self.v_ref_audio)
                   ).pack(side="left", padx=(4,0)); R += 1

        row("参考音频台词：", ttk.Entry, textvariable=self.v_prompt_text, width=36)

        # 语言下拉（prompt_lang）
        ttk.Label(lf, text="参考音频语言：").grid(row=R, column=0, sticky="w", padx=8, pady=6)
        cb_pl = ttk.Combobox(lf, textvariable=self.v_prompt_lang, state="readonly", width=18)
        cb_pl["values"] = [f"{d}  [{c}]" for d, c in LANG_OPTIONS]
        cb_pl.grid(row=R, column=1, sticky="w", padx=8, pady=6); R += 1

        # 语言下拉（text_lang）
        ttk.Label(lf, text="合成文本语言：").grid(row=R, column=0, sticky="w", padx=8, pady=6)
        cb_tl = ttk.Combobox(lf, textvariable=self.v_text_lang, state="readonly", width=18)
        cb_tl["values"] = [f"{d}  [{c}]" for d, c in LANG_OPTIONS]
        cb_tl.grid(row=R, column=1, sticky="w", padx=8, pady=6); R += 1

        # cut 方法
        ttk.Label(lf, text="分割方法：").grid(row=R, column=0, sticky="w", padx=8, pady=6)
        cb_cut = ttk.Combobox(lf, textvariable=self.v_cut_method, state="readonly", width=28)
        cb_cut["values"] = [f"{d}" for d, c in CUT_OPTIONS]
        cb_cut.grid(row=R, column=1, sticky="w", padx=8, pady=6); R += 1

        # 语速滑块
        ttk.Label(lf, text="语速：").grid(row=R, column=0, sticky="w", padx=8, pady=6)
        spd_frame = ttk.Frame(lf); spd_frame.grid(row=R, column=1, sticky="ew", padx=8, pady=6)
        self.speed_label = ttk.Label(spd_frame, text="1.00", width=5)
        sc = ttk.Scale(spd_frame, from_=0.5, to=2.0, variable=self.v_speed, orient="horizontal",
                       command=lambda v: self.speed_label.config(text=f"{float(v):.2f}"))
        sc.pack(side="left", fill="x", expand=True)
        self.speed_label.pack(side="left", padx=6); R += 1

        lf.columnconfigure(1, weight=1)

        btn_row = ttk.Frame(lf); btn_row.grid(row=R, column=0, columnspan=2, pady=12)
        ttk.Button(btn_row, text="💾 保存角色", style="Accent.TButton",
                   command=self._role_save).pack(side="left", padx=6)
        ttk.Button(btn_row, text="🔄 重置", command=self._role_reset).pack(side="left", padx=6)

    def _lang_display(self, code):
        for d, c in LANG_OPTIONS:
            if c == code: return f"{d}  [{c}]"
        return f"自动  [auto]"

    def _lang_code(self, display):
        for d, c in LANG_OPTIONS:
            if f"{d}  [{c}]" == display: return c
        return "auto"

    def _cut_display(self, code):
        for d, c in CUT_OPTIONS:
            if c == code: return d
        return CUT_OPTIONS[-1][0]

    def _cut_code(self, display):
        for d, c in CUT_OPTIONS:
            if d == display: return c
        return "cut5"

    def _refresh_role_list(self, select_name=None):
        self.role_listbox.delete(0, "end")
        for name in self.cfg["roles"]:
            self.role_listbox.insert("end", name)
        if select_name:
            names = list(self.cfg["roles"].keys())
            if select_name in names:
                idx = names.index(select_name)
                self.role_listbox.selection_set(idx)
                self.role_listbox.see(idx)
                self._load_role(select_name)
        elif self.role_listbox.size() > 0:
            self.role_listbox.selection_set(0)
            self._load_role(list(self.cfg["roles"].keys())[0])

    def _on_role_select(self, _=None):
        sel = self.role_listbox.curselection()
        if not sel: return
        name = self.role_listbox.get(sel[0])
        self._load_role(name)

    def _load_role(self, name):
        r = self.cfg["roles"].get(name, {})
        self.v_role_name.set(name)
        self.v_ref_audio.set(r.get("ref_audio_path", ""))
        self.v_prompt_text.set(r.get("prompt_text", ""))
        self.v_prompt_lang.set(self._lang_display(r.get("prompt_lang", "zh")))
        self.v_text_lang.set(self._lang_display(r.get("text_lang", "zh")))
        self.v_cut_method.set(self._cut_display(r.get("text_split_method", "cut5")))
        spd = r.get("speed_factor", 1.0)
        self.v_speed.set(spd)
        self.speed_label.config(text=f"{spd:.2f}")
        self._editing_role = name

    def _role_save(self):
        old_name = getattr(self, "_editing_role", None)
        new_name = self.v_role_name.get().strip()
        if not new_name:
            messagebox.showwarning("提示", "角色名称不能为空"); return
        entry = {
            "ref_audio_path":   self.v_ref_audio.get().strip(),
            "prompt_text":      self.v_prompt_text.get().strip(),
            "prompt_lang":      self._lang_code(self.v_prompt_lang.get()),
            "text_lang":        self._lang_code(self.v_text_lang.get()),
            "text_split_method": self._cut_code(self.v_cut_method.get()),
            "speed_factor":     round(self.v_speed.get(), 2),
        }
        if old_name and old_name != new_name and old_name in self.cfg["roles"]:
            del self.cfg["roles"][old_name]
        self.cfg["roles"][new_name] = entry
        self._editing_role = new_name
        self._refresh_role_list(select_name=new_name)
        self._log_msg(f"[角色] '{new_name}' 已保存")

    def _role_reset(self):
        name = getattr(self, "_editing_role", None)
        if name: self._load_role(name)

    def _role_add(self):
        name = f"新角色{len(self.cfg['roles'])+1}"
        self.cfg["roles"][name] = {
            "ref_audio_path": "", "prompt_text": "",
            "prompt_lang": "zh", "text_lang": "zh",
            "text_split_method": "cut5", "speed_factor": 1.0
        }
        self._refresh_role_list(select_name=name)

    def _role_delete(self):
        sel = self.role_listbox.curselection()
        if not sel: return
        name = self.role_listbox.get(sel[0])
        if messagebox.askyesno("确认", f"删除角色「{name}」？"):
            del self.cfg["roles"][name]
            self._refresh_role_list()

    # ════════════════════════════════════════════════
    #  标签页：服务器管理
    # ════════════════════════════════════════════════
    def _build_servers_tab(self):
        f = self.tab_servers

        top_bar = ttk.Frame(f); top_bar.pack(fill="x", padx=12, pady=(10,0))
        ttk.Button(top_bar, text="＋ 添加机器组", style="Success.TButton",
                   command=self._server_add_group).pack(side="left", padx=4)
        ttk.Button(top_bar, text="🔍 检测所有服务器", style="Accent.TButton",
                   command=self._server_check_all).pack(side="left", padx=4)
        ttk.Button(top_bar, text="✕ 删除选中", style="Danger.TButton",
                   command=self._server_delete).pack(side="left", padx=4)
        ttk.Button(top_bar, text="⬆ 上移", command=self._server_move_up).pack(side="left", padx=4)
        ttk.Button(top_bar, text="⬇ 下移", command=self._server_move_down).pack(side="left", padx=4)

        tree_frame = ttk.Frame(f); tree_frame.pack(fill="both", expand=True, padx=12, pady=8)
        sb = ttk.Scrollbar(tree_frame); sb.pack(side="right", fill="y")
        self.srv_tree = ttk.Treeview(tree_frame, yscrollcommand=sb.set,
                                      columns=("type", "url", "status"), show="tree headings")
        self.srv_tree.heading("#0",     text="名称",   anchor="w")
        self.srv_tree.heading("type",   text="类型",   anchor="w")
        self.srv_tree.heading("url",    text="地址",   anchor="w")
        self.srv_tree.heading("status", text="状态",   anchor="w")
        self.srv_tree.column("#0",     width=180, stretch=False)
        self.srv_tree.column("type",   width=80,  stretch=False)
        self.srv_tree.column("url",    width=300)
        self.srv_tree.column("status", width=140, stretch=False)
        self.srv_tree.pack(fill="both", expand=True)
        sb.config(command=self.srv_tree.yview)
        self.srv_tree.bind("<Double-1>", self._server_edit)

        edit_lf = ttk.LabelFrame(f, text="编辑选中项", padding=12)
        edit_lf.pack(fill="x", padx=12, pady=(0,10))
        ttk.Label(edit_lf, text="名称：").grid(row=0, column=0, padx=6, pady=4, sticky="w")
        self.v_srv_name = tk.StringVar()
        ttk.Entry(edit_lf, textvariable=self.v_srv_name, width=24).grid(row=0, column=1, padx=6, pady=4, sticky="w")
        ttk.Label(edit_lf, text="地址（机器组填空，IP行填完整URL）：").grid(row=0, column=2, padx=6, pady=4, sticky="w")
        self.v_srv_url = tk.StringVar()
        ttk.Entry(edit_lf, textvariable=self.v_srv_url, width=36).grid(row=0, column=3, padx=6, pady=4, sticky="ew")
        ttk.Button(edit_lf, text="应用", style="Accent.TButton",
                   command=self._server_apply_edit).grid(row=0, column=4, padx=10, pady=4)
        ttk.Button(edit_lf, text="＋ 添加IP到选中组",
                   command=self._server_add_ip).grid(row=0, column=5, padx=4, pady=4)
        edit_lf.columnconfigure(3, weight=1)

        self._refresh_server_tree()

    def _refresh_server_tree(self):
        self.srv_tree.delete(*self.srv_tree.get_children())
        for gi, grp in enumerate(self.cfg["server_groups"]):
            gid = self.srv_tree.insert("", "end", iid=f"g{gi}",
                                        text=grp["name"],
                                        values=("机器组", "", ""),
                                        open=True)
            for ui, url in enumerate(grp["urls"]):
                self.srv_tree.insert(gid, "end", iid=f"g{gi}u{ui}",
                                      text=f"  IP {ui+1}",
                                      values=("IP", url, "—"))

    def _server_add_group(self):
        name = f"新机器组{len(self.cfg['server_groups'])+1}"
        self.cfg["server_groups"].append({"name": name, "urls": []})
        self._refresh_server_tree()

    def _server_add_ip(self):
        sel = self.srv_tree.focus()
        if not sel: messagebox.showinfo("提示", "请先选中一个机器组"); return
        # 找到所属机器组
        if sel.startswith("g") and "u" not in sel:
            gi = int(sel[1:])
        elif sel.startswith("g") and "u" in sel:
            gi = int(sel[1:sel.index("u")])
        else: return
        url = self.v_srv_url.get().strip()
        if not url: messagebox.showwarning("提示", "请在编辑栏填写URL"); return
        self.cfg["server_groups"][gi]["urls"].append(url)
        self._refresh_server_tree()
        self.v_srv_url.set("")

    def _server_delete(self):
        sel = self.srv_tree.focus()
        if not sel: return
        if "u" not in sel:
            gi = int(sel[1:])
            if messagebox.askyesno("确认", f"删除机器组「{self.cfg['server_groups'][gi]['name']}」及其所有IP？"):
                del self.cfg["server_groups"][gi]
                self._refresh_server_tree()
        else:
            gi = int(sel[1:sel.index("u")])
            ui = int(sel[sel.index("u")+1:])
            if messagebox.askyesno("确认", "删除此IP？"):
                del self.cfg["server_groups"][gi]["urls"][ui]
                self._refresh_server_tree()

    def _server_move_up(self):
        sel = self.srv_tree.focus()
        if not sel or "u" in sel: return
        gi = int(sel[1:])
        if gi == 0: return
        g = self.cfg["server_groups"]
        g[gi-1], g[gi] = g[gi], g[gi-1]
        self._refresh_server_tree()

    def _server_move_down(self):
        sel = self.srv_tree.focus()
        if not sel or "u" in sel: return
        gi = int(sel[1:])
        g = self.cfg["server_groups"]
        if gi >= len(g)-1: return
        g[gi], g[gi+1] = g[gi+1], g[gi]
        self._refresh_server_tree()

    def _server_edit(self, _=None):
        sel = self.srv_tree.focus()
        if not sel: return
        if "u" not in sel:
            gi = int(sel[1:])
            self.v_srv_name.set(self.cfg["server_groups"][gi]["name"])
            self.v_srv_url.set("")
        else:
            gi = int(sel[1:sel.index("u")])
            ui = int(sel[sel.index("u")+1:])
            self.v_srv_name.set(f"IP {ui+1}")
            self.v_srv_url.set(self.cfg["server_groups"][gi]["urls"][ui])

    def _server_apply_edit(self):
        sel = self.srv_tree.focus()
        if not sel: return
        if "u" not in sel:
            gi = int(sel[1:])
            self.cfg["server_groups"][gi]["name"] = self.v_srv_name.get().strip()
        else:
            gi = int(sel[1:sel.index("u")])
            ui = int(sel[sel.index("u")+1:])
            url = self.v_srv_url.get().strip()
            if url: self.cfg["server_groups"][gi]["urls"][ui] = url
        self._refresh_server_tree()

    def _server_check_all(self):
        self._log_msg("[服务器检测] 开始检测所有IP...")
        def _check():
            for gi, grp in enumerate(self.cfg["server_groups"]):
                for ui, url in enumerate(grp["urls"]):
                    ok, msg = check_server(url)
                    icon = "✅" if ok else "❌"
                    iid = f"g{gi}u{ui}"
                    self.after(0, lambda i=iid, m=msg: self.srv_tree.set(i, "status", m))
                    self._log_msg(f"  {icon} {url}  → {msg}")
            self._log_msg("[服务器检测] 完成")
        threading.Thread(target=_check, daemon=True).start()

    # ════════════════════════════════════════════════
    #  标签页：测试播放
    # ════════════════════════════════════════════════
    def _build_test_tab(self):
        f = self.tab_test

        top = ttk.LabelFrame(f, text="测试参数", padding=14)
        top.pack(fill="x", padx=12, pady=(12,6))

        ttk.Label(top, text="角色：").grid(row=0, column=0, padx=6, pady=6, sticky="w")
        self.v_test_role = tk.StringVar()
        self.cb_test_role = ttk.Combobox(top, textvariable=self.v_test_role, state="readonly", width=14)
        self.cb_test_role.grid(row=0, column=1, padx=6, pady=6, sticky="w")
        self.nb.bind("<<NotebookTabChanged>>", self._on_tab_change)

        ttk.Label(top, text="测试台词：").grid(row=0, column=2, padx=6, pady=6, sticky="w")
        self.v_test_text = tk.StringVar(
            value="旅行者，今天天气真好！可莉想去原野抓松鼠。蹦蹦炸弹也要带上！万一遇到丘丘人，就用炸弹轰他们！炸完之后我们再去采蘑菇，可莉最喜欢吃蘑菇汤了！")
        ttk.Entry(top, textvariable=self.v_test_text, width=54).grid(row=0, column=3, padx=6, pady=6, sticky="ew")
        top.columnconfigure(3, weight=1)

        btn_row = ttk.Frame(f); btn_row.pack(fill="x", padx=12, pady=4)
        self.btn_play = ttk.Button(btn_row, text="▶  生成并播放", style="Accent.TButton",
                                    command=self._test_play)
        self.btn_play.pack(side="left", padx=4)
        ttk.Button(btn_row, text="⏹  停止", style="Danger.TButton",
                   command=self._test_stop).pack(side="left", padx=4)
        ttk.Button(btn_row, text="🗑  清空日志", command=self._log_clear).pack(side="right", padx=4)

        # 进度条
        self.progress_var = tk.DoubleVar(value=0)
        pb = ttk.Progressbar(f, variable=self.progress_var, maximum=100)
        pb.pack(fill="x", padx=12, pady=(2,4))

        # 日志
        log_lf = ttk.LabelFrame(f, text="运行日志", padding=8)
        log_lf.pack(fill="both", expand=True, padx=12, pady=(0,10))
        self.log_box = scrolledtext.ScrolledText(log_lf, bg=self.colors["SEL"],
                                                  fg=self.colors["FG"],
                                                  insertbackground=self.colors["FG"],
                                                  font=("Consolas", 10),
                                                  state="disabled", wrap="word")
        self.log_box.pack(fill="both", expand=True)

        self._test_thread = None
        self._test_stop_flag = False

    def _on_tab_change(self, _=None):
        names = list(self.cfg["roles"].keys())
        self.cb_test_role["values"] = names
        if names and not self.v_test_role.get():
            self.v_test_role.set(names[0])

    def _test_play(self):
        if self._test_thread and self._test_thread.is_alive(): return
        role_name = self.v_test_role.get()
        text = self.v_test_text.get().strip()
        if not role_name or not text:
            messagebox.showwarning("提示", "请选择角色并填写测试台词"); return
        self._test_stop_flag = False
        self.btn_play.config(state="disabled")
        self.progress_var.set(0)
        self._test_thread = threading.Thread(target=self._test_worker,
                                              args=(role_name, text), daemon=True)
        self._test_thread.start()

    def _test_stop(self):
        self._test_stop_flag = True
        self._log_msg("[停止] 已发出停止信号，当前句合成完后中断")

    def _test_worker(self, role_name, text):
        cfg = self.cfg
        role_cfg = cfg["roles"].get(role_name)
        if not role_cfg:
            self._log_msg(f"[错误] 角色 '{role_name}' 不存在"); self._test_done(); return

        self._log_msg(f"\n{'='*52}")
        self._log_msg(f"[{role_name}] {text}")
        self._log_msg(f"{'='*52}")

        sentences = split_sentences(text)
        total = len(sentences)
        threshold = cfg.get("parallel_threshold", 4)
        self._log_msg(f"[分句] 共 {total} 句，并行阈值={threshold}")
        self._log_msg(f"[模式] {'流水线并行' if total >= threshold else '串行'}")
        self._log_msg(f"  → {sentences}")

        server_groups = [grp["urls"] for grp in cfg["server_groups"]]
        if not server_groups:
            self._log_msg("[错误] 没有配置服务器"); self._test_done(); return

        t_start = datetime.now()

        if total < threshold:
            # 串行
            all_urls = []
            for g in server_groups: all_urls += g
            wav_list = []
            for i, s in enumerate(sentences):
                if self._test_stop_flag: break
                payload = build_payload(role_cfg, s)
                audio, used = request_tts(all_urls, payload)
                pct = (i+1)/total*100
                self.after(0, lambda p=pct: self.progress_var.set(p))
                if audio:
                    wav_list.append(audio)
                    host = used.split("/")[2] if used else "?"
                    self._log_msg(f"  [OK] 句{i+1}/{total} ({len(audio):,} bytes) ← {host}")
                else:
                    self._log_msg(f"  [--] 句{i+1}/{total} 失败，跳过")
            wav_data = merge_wav_bytes(wav_list) if len(wav_list) > 1 else (wav_list[0] if wav_list else None)
        else:
            # 并行
            results = [None]*total
            lock = threading.Lock()
            N = len(server_groups)
            done_count = [0]

            def worker(idx, sentence, group):
                payload = build_payload(role_cfg, sentence)
                audio, used = request_tts(group, payload)
                with lock:
                    if audio:
                        results[idx] = audio
                        host = used.split("/")[2] if used else "?"
                        self._log_msg(f"  [OK] 句{idx+1}/{total} ({len(audio):,} bytes) ← {host}")
                    else:
                        self._log_msg(f"  [--] 句{idx+1}/{total} 失败")
                    done_count[0] += 1
                    self.after(0, lambda: self.progress_var.set(done_count[0]/total*100))

            for batch_start in range(0, total, N):
                if self._test_stop_flag: break
                batch = sentences[batch_start:batch_start+N]
                threads = []
                for j, s in enumerate(batch):
                    t = threading.Thread(target=worker,
                                          args=(batch_start+j, s, server_groups[j % N]))
                    threads.append(t); t.start()
                for t in threads: t.join()

            # 重试失败句
            for i, s in enumerate(sentences):
                if results[i] is None and not self._test_stop_flag:
                    self._log_msg(f"  [重试] 句{i+1} 换服务器...")
                    fb = server_groups[(i+1) % N]
                    audio, used = request_tts(fb, build_payload(role_cfg, s))
                    if audio:
                        results[i] = audio
                        self._log_msg(f"  [OK] 句{i+1} 重试成功")
                    else:
                        self._log_msg(f"  [--] 句{i+1} 重试失败")

            valid = [r for r in results if r is not None]
            wav_data = merge_wav_bytes(valid) if valid else None

        if not wav_data:
            self._log_msg("[错误] 无有效音频"); self._test_done(); return

        # 保存
        audio_dir = cfg.get("audio_dir", ".")
        os.makedirs(audio_dir, exist_ok=True)
        safe = re.sub(r'[\\/:*?"<>|\s]', '', text)[:20]
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        fname = f"{role_name}-{safe}-{ts}.wav"
        out_path = os.path.join(audio_dir, fname)
        with open(out_path, "wb") as fp: fp.write(wav_data)

        # 时长
        with wave.open(io.BytesIO(wav_data), 'rb') as wf:
            duration = wf.getnframes() / wf.getframerate()

        t_gen = (datetime.now() - t_start).total_seconds()
        self._log_msg(f"[完成] 耗时 {t_gen:.2f}s | 时长 {duration:.2f}s | 加速比 {duration/t_gen:.1f}x")
        self._log_msg(f"[保存] {fname}")
        self.after(0, lambda: self.progress_var.set(100))

        # 播放
        try:
            play_wav(out_path)
        except Exception as e:
            self._log_msg(f"[播放] 失败: {e}")

        self._test_done()

    def _test_done(self):
        self.after(0, lambda: self.btn_play.config(state="normal"))

    def _log_msg(self, msg):
        def _do():
            self.log_box.config(state="normal")
            self.log_box.insert("end", msg + "\n")
            self.log_box.see("end")
            self.log_box.config(state="disabled")
        self.after(0, _do)

    def _log_clear(self):
        self.log_box.config(state="normal")
        self.log_box.delete("1.0", "end")
        self.log_box.config(state="disabled")

    # ════════════════════════════════════════════════
    #  工具
    # ════════════════════════════════════════════════
    def _browse_dir(self, var):
        path = filedialog.askdirectory(initialdir=var.get() or "/")
        if path: var.set(path)

    def _browse_file(self, var):
        path = filedialog.askopenfilename(filetypes=[("WAV文件", "*.wav"), ("所有文件", "*.*")])
        if path: var.set(path)

    def _collect_global(self):
        self.cfg["audio_dir"] = self.v_audio_dir.get().strip()
        self.cfg["parallel_threshold"] = self.v_threshold.get()

    def _save(self):
        self._collect_global()
        save_config(self.cfg)
        messagebox.showinfo("保存成功", f"配置已保存到：\n{CONFIG_PATH}")

    def _export(self):
        self._collect_global()
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON文件", "*.json"), ("所有文件", "*.*")],
            initialfile="tts_config_export.json"
        )
        if path:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=2)
            messagebox.showinfo("导出成功", f"已导出到：\n{path}")

    def _import(self):
        path = filedialog.askopenfilename(
            filetypes=[("JSON文件", "*.json"), ("所有文件", "*.*")]
        )
        if not path: return
        try:
            with open(path, "r", encoding="utf-8") as f:
                new_cfg = json.load(f)
            self.cfg.update(new_cfg)
            # 刷新所有 UI
            self.v_audio_dir.set(self.cfg.get("audio_dir", ""))
            self.v_threshold.set(self.cfg.get("parallel_threshold", 4))
            self._refresh_role_list()
            self._refresh_server_tree()
            messagebox.showinfo("导入成功", f"已从以下文件导入配置：\n{path}")
        except Exception as e:
            messagebox.showerror("导入失败", str(e))

    def _on_close(self):
        if messagebox.askyesno("退出", "保存配置后退出？"):
            self._collect_global()
            save_config(self.cfg)
        self.destroy()

# ════════════════════════════════════════════════════════
if __name__ == "__main__":
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    app = TTSConfigApp()
    app.mainloop()
