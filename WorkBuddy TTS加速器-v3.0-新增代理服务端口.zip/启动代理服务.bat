@echo off
cd /d "%~dp0"
echo 启动 TTS 代理服务...
python tts_proxy.py --port 9882
pause
