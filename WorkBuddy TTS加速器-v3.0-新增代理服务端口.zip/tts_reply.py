"""
WorkBuddy TTS 并行加速回复工具
策略：智能分句 → 两台服务器并发合成 → 按序合并 WAV → 播放
用法：python tts_reply.py "角色名" "回复文本"
"""
import sys
import os
import re
import io
import json
import wave
import winsound
import urllib.request
import urllib.error
import threading
from datetime import datetime

# 强制 stdout 使用 utf-8，避免 Windows GBK 编码报错
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8')

AUDIO_DIR = r"G:\WorkBuddy\generated_audio"

# ── 服务器分组（每组为一台物理机器，组内任一IP可用即可）──
SERVER_GROUPS = [
    # 笔记本（首选）
    [
        "http://192.168.28.3:9880/tts",
        "http://192.168.31.5:9880/tts",
        "http://192.168.28.7:9880/tts",
    ],
    # 华硕主机（备选）
    [
        "http://192.168.31.177:9880/tts",
        "http://192.168.28.2:9880/tts",
        "http://192.168.28.127:9880/tts",
    ],
]

# ── 角色配置 ──
ROLES = {
    "可莉": {
        "ref_audio_path": "audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
        "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
        "prompt_lang": "zh",
        "text_lang": "zh",
        "text_split_method": "cut5",
    },
    "瑶瑶": {
        "ref_audio_path": "audio/yaoyao-甘雨姐姐，你没事吧？要不要喝点水，或者吃点别的什么调节一下？.wav",
        "prompt_text": "甘雨姐姐，你没事吧？要不要喝点水，或者吃点别的什么调节一下？",
        "prompt_lang": "zh",
        "text_lang": "auto",
        "text_split_method": "cut5",
    },
    "纳西妲": {
        "ref_audio_path": "audio/nahida-如果是说踏鞴砂那个神秘事件与倾奇者之类的.wav",
        "prompt_text": "如果是说踏鞴砂那个神秘事件与倾奇者之类的",
        "prompt_lang": "zh",
        "text_lang": "zh",
        "text_split_method": "cut5",
        "speed_factor": 0.85,
    },
}

# ── 智能分句 ──
def split_sentences(text):
    """
    按中文标点智能分句，保证语序完整、语义完整。
    规则：
      1. 按句末标点（。！？…～）切分
      2. 短句（<8字）尽量与下一句合并，避免碎片化
      3. 长句（>40字）按逗号、分号二次切分
      4. 最终每组不超过50字
    """
    if not text.strip():
        return []

    # 第一步：按句末标点切分
    parts = re.split(r'(?<=[。！？…～\!\?])', text)
    parts = [p.strip() for p in parts if p.strip()]

    # 第二步：短句合并（小于8字的短句合并到下一句）
    merged = []
    buf = ""
    for p in parts:
        buf += p
        if len(buf) >= 8:
            merged.append(buf)
            buf = ""
    if buf:
        if merged:
            merged[-1] += buf
        else:
            merged.append(buf)

    # 第三步：超长句按逗号/分号二次切分
    result = []
    for s in merged:
        if len(s) > 50:
            subs = re.split(r'(?<=[，,；;、])', s)
            subs = [x.strip() for x in subs if x.strip()]
            # 再次合并过短的子句
            sub_buf = ""
            for sub in subs:
                sub_buf += sub
                if len(sub_buf) >= 15:
                    result.append(sub_buf)
                    sub_buf = ""
            if sub_buf:
                if result:
                    result[-1] += sub_buf
                else:
                    result.append(sub_buf)
        else:
            result.append(s)

    return result if result else [text]

# ── 构建 TTS 请求体 ──
def build_payload(role, text):
    cfg = ROLES.get(role, ROLES["可莉"])
    return {
        "text": text,
        "text_lang": cfg.get("text_lang", "zh"),
        "ref_audio_path": cfg["ref_audio_path"],
        "prompt_text": cfg["prompt_text"],
        "prompt_lang": cfg["prompt_lang"],
        "top_k": 5,
        "top_p": 1,
        "temperature": 1,
        "text_split_method": cfg.get("text_split_method", "cut0"),   # 已手动分句，不再二次切分
        "batch_size": 1,
        "batch_threshold": 0.75,
        "split_bucket": True,
        "return_fragment": False,
        "speed_factor": cfg.get("speed_factor", 1.0),
        "streaming_mode": False,
        "seed": -1,
        "parallel_infer": True,
        "repetition_penalty": 1.35,
        "aux_ref_audio_paths": []
    }

# ── 向单台服务器组发请求（组内自动切换） ──
def request_tts(server_group, payload, timeout=60):
    data = json.dumps(payload).encode("utf-8")
    for url in server_group:
        try:
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
            r = urllib.request.urlopen(req, timeout=timeout)
            audio = r.read()
            if len(audio) > 100:
                return audio, url
        except urllib.error.HTTPError as e:
            err = e.read().decode(errors='replace')[:80]
            print(f"  [!] {url} HTTP {e.code}: {err}")
        except Exception as e:
            print(f"  [!] {url} {type(e).__name__}: {e}")
    return None, None

# ── WAV 字节流合并（保持语序） ──
def merge_wav_bytes(wav_list):
    """将多段 WAV 字节流按顺序合并为一个完整 WAV，零间隙拼接"""
    if not wav_list:
        return None
    if len(wav_list) == 1:
        return wav_list[0]

    frames_list = []
    params = None
    for wav_bytes in wav_list:
        try:
            with wave.open(io.BytesIO(wav_bytes), 'rb') as wf:
                if params is None:
                    params = wf.getparams()
                frames_list.append(wf.readframes(wf.getnframes()))
        except Exception as e:
            print(f"  [!] WAV解析失败: {e}")
            continue

    if not frames_list or params is None:
        return None

    out_buf = io.BytesIO()
    with wave.open(out_buf, 'wb') as wf:
        wf.setparams(params)
        for frames in frames_list:
            wf.writeframes(frames)
    return out_buf.getvalue()

# ── 文件命名 ──
def make_filename(role, text):
    safe = re.sub(r'[\\/:*?"<>|\s]', '', text)[:20]
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"{role}-{safe}-{ts}.wav"

# ── 主函数 ──
def tts_reply(role, text):
    print(f"\n{'='*55}")
    print(f"[{role}] {text}")
    print(f"{'='*55}")

    sentences = split_sentences(text)
    total = len(sentences)
    print(f"[分句] 共 {total} 句: {sentences}")

    if total == 0:
        return

    t_start = datetime.now()

    # 单句或短文本（<=3句）：串行处理，避免GPU竞争
    if total <= 3:
        print(f"[合成] 串行模式（{total}句）")
        all_servers = SERVER_GROUPS[0] + SERVER_GROUPS[1]
        wav_list = []
        for i, s in enumerate(sentences):
            payload = build_payload(role, s)
            audio, used = request_tts(all_servers, payload)
            if audio:
                wav_list.append(audio)
                print(f"  [OK] 句{i+1}/{total} ({len(audio)} bytes) <- {used.split('/')[2]}")
            else:
                print(f"  [--] 句{i+1}/{total} 失败，跳过")
        if not wav_list:
            print("[错误] 所有片段合成失败")
            return
        wav_data = merge_wav_bytes(wav_list) if len(wav_list) > 1 else wav_list[0]
    else:
        # 长文本（>3句）：流水线并行，每台服务器同时只处理1句
        # 策略：每轮同时启动 N_MACHINES 个线程（每台机器1个），
        #       等这一轮全部完成后再处理下一轮，保证每台服务器不被过载
        N_MACHINES = len(SERVER_GROUPS)
        results = [None] * total
        lock = threading.Lock()

        def worker(idx, sentence, group):
            payload = build_payload(role, sentence)
            audio, used = request_tts(group, payload)
            with lock:
                if audio:
                    results[idx] = audio
                    print(f"  [OK] 句{idx+1}/{total} 完成 ({len(audio)} bytes) <- {used.split('/')[2]}")
                else:
                    print(f"  [--] 句{idx+1}/{total} 失败")

        # 按轮次分批处理，每轮最多 N_MACHINES 句并行
        for batch_start in range(0, total, N_MACHINES):
            batch = sentences[batch_start:batch_start + N_MACHINES]
            threads = []
            for j, s in enumerate(batch):
                idx = batch_start + j
                group = SERVER_GROUPS[j % N_MACHINES]
                t = threading.Thread(target=worker, args=(idx, s, group))
                threads.append(t)
                t.start()
            for t in threads:
                t.join()

        # 失败的句子换另一台服务器重试
        for i, s in enumerate(sentences):
            if results[i] is None:
                print(f"  [重试] 句{i+1} 换服务器重试...")
                fallback_group = SERVER_GROUPS[(i + 1) % N_MACHINES]
                payload = build_payload(role, s)
                audio, used = request_tts(fallback_group, payload)
                if audio:
                    results[i] = audio
                    print(f"  [OK] 句{i+1} 重试成功")
                else:
                    print(f"  [--] 句{i+1} 重试仍失败，跳过")

        # 过滤掉失败的，保持语序合并
        valid = [r for r in results if r is not None]
        if not valid:
            print("[错误] 全部片段合成失败")
            return

        wav_data = merge_wav_bytes(valid)
        if not wav_data:
            print("[错误] WAV 合并失败")
            return

    t_gen = (datetime.now() - t_start).total_seconds()

    # 保存文件
    os.makedirs(AUDIO_DIR, exist_ok=True)
    out_path = os.path.join(AUDIO_DIR, make_filename(role, text))
    with open(out_path, "wb") as f:
        f.write(wav_data)

    # 获取时长
    with wave.open(io.BytesIO(wav_data), 'rb') as wf:
        duration = wf.getnframes() / wf.getframerate()

    print(f"[完成] 生成耗时 {t_gen:.2f}s | 音频时长 {duration:.2f}s | 加速比 {duration/t_gen:.1f}x")
    print(f"[保存] {os.path.basename(out_path)}")

    # 播放
    winsound.PlaySound(out_path, winsound.SND_FILENAME)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法: python tts_reply.py <角色名> <文本>")
        sys.exit(1)
    tts_reply(sys.argv[1], sys.argv[2])
