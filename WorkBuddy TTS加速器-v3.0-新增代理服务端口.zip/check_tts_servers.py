import urllib.request
import urllib.error
import sys

sys.stdout.reconfigure(encoding='utf-8')

servers = [
    # 笔记本（首选，多网卡冗余）
    ("笔记本-网卡1", "http://192.168.28.3:9880/tts"),
    ("笔记本-网卡2", "http://192.168.31.5:9880/tts"),
    ("笔记本-网卡3", "http://192.168.28.7:9880/tts"),
    # 华硕主机（备选，多网卡冗余）
    ("华硕主机-网卡1", "http://192.168.31.177:9880/tts"),
    ("华硕主机-网卡2", "http://192.168.28.2:9880/tts"),
    ("华硕主机-网卡3", "http://192.168.28.127:9880/tts"),
]

for label, url in servers:
    try:
        req = urllib.request.Request(url, method="GET")
        r = urllib.request.urlopen(req, timeout=5)
        print(f"[在线] {label}: {url}")
    except urllib.error.HTTPError as e:
        print(f"[在线] {label}: {url}  (HTTP {e.code})")
    except Exception as e:
        print(f"[离线] {label}: {url}  ({type(e).__name__})")
