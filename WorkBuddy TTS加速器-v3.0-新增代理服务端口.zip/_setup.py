import os, shutil
os.makedirs(r'G:\WorkBuddy\TTS加速器', exist_ok=True)
shutil.copy(r'G:\WorkBuddy\辅助工具\tts_reply.py', r'G:\WorkBuddy\TTS加速器\tts_reply.py')
shutil.copy(r'G:\WorkBuddy\辅助工具\check_tts_servers.py', r'G:\WorkBuddy\TTS加速器\check_tts_servers.py')
print('files copied ok')
