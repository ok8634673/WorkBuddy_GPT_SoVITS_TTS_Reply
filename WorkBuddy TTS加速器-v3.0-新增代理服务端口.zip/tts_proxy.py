"""
TTS 代理服务器 (tts_proxy.py)
────────────────────────────────────────────
监听本地端口，接收标准 GPT-SoVITS /tts 请求，
透明转发给后端服务器集群，支持：
  - Round-robin 轮询负载均衡
  - 自动跳过禁用服务器
  - 单台失败自动切换下一台
  - 健康检查（定时探活）
  - 实时状态回调（供 GUI 使用）

用法：
  python tts_proxy.py [--port 9882] [--config tts_gui_config.json]
"""

import json
import os
import sys
import time
import threading
import urllib.request
import urllib.error
import itertools
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime

# ── 强制 UTF-8 输出 ──────────────────────────────────────
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tts_gui_config.json")


def load_backends(config_path=CONFIG_PATH):
    """从配置文件读取所有 enabled 的后端 URL"""
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        backends = []
        for grp in cfg.get("server_groups", []):
            if not grp.get("enabled", True):
                continue
            for u in grp.get("urls", []):
                url = u["url"] if isinstance(u, dict) else u
                en  = u.get("enabled", True) if isinstance(u, dict) else True
                if en:
                    backends.append(url)
        return backends
    except Exception as e:
        return []


class ProxyState:
    """代理服务全局状态，供 HTTPHandler 共享"""
    def __init__(self):
        self.backends: list[str] = []
        self.lock = threading.Lock()
        self._rr_iter = None          # round-robin 迭代器
        self.total_req  = 0
        self.total_ok   = 0
        self.total_fail = 0
        self.log_cb = None            # GUI 日志回调 fn(msg: str)
        self.stats_cb = None          # GUI 统计回调 fn(req, ok, fail)

    def reload(self, config_path=CONFIG_PATH):
        backends = load_backends(config_path)
        with self.lock:
            self.backends = backends
            self._rr_iter = itertools.cycle(backends) if backends else None
        self._log(f"[配置] 已加载 {len(backends)} 个后端: {backends}")

    def next_backend(self) -> str | None:
        with self.lock:
            if not self._rr_iter:
                return None
            return next(self._rr_iter)

    def _log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}"
        print(line, flush=True)
        if self.log_cb:
            try:
                self.log_cb(line)
            except Exception:
                pass

    def _update_stats(self):
        if self.stats_cb:
            try:
                self.stats_cb(self.total_req, self.total_ok, self.total_fail)
            except Exception:
                pass

    def log(self, msg):
        self._log(msg)

    def record_ok(self):
        self.total_ok += 1
        self._update_stats()

    def record_fail(self):
        self.total_fail += 1
        self._update_stats()

    def record_req(self):
        self.total_req += 1
        self._update_stats()


# 全局状态单例
_state = ProxyState()


class TTSProxyHandler(BaseHTTPRequestHandler):
    """HTTP 请求处理器，接收 /tts POST 请求并转发"""

    def log_message(self, fmt, *args):
        # 屏蔽默认日志，改用自定义
        pass

    def do_GET(self):
        if self.path == "/status":
            self._send_status()
        elif self.path == "/backends":
            self._send_backends()
        else:
            self._not_found()

    def do_POST(self):
        if self.path not in ("/tts", "/tts/"):
            self._not_found()
            return
        self._handle_tts()

    def _handle_tts(self):
        # 读取请求体
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length > 0 else b""

        _state.record_req()

        with _state.lock:
            backends = list(_state.backends)

        if not backends:
            _state.log("[错误] 无可用后端服务器")
            _state.record_fail()
            self._respond(503, b'{"error":"no backends available"}')
            return

        # 轮询，失败自动切换，最多尝试所有后端
        tried = set()
        tried_count = 0
        max_try = len(backends)

        while tried_count < max_try:
            url = _state.next_backend()
            if url in tried:
                # 跳过已试过的，但最多循环一圈
                tried_count += 1
                continue
            tried.add(url)
            tried_count += 1

            t0 = time.time()
            try:
                req = urllib.request.Request(
                    url, data=body,
                    headers={
                        "Content-Type": self.headers.get("Content-Type", "application/json"),
                        "Content-Length": str(len(body)),
                    }
                )
                resp = urllib.request.urlopen(req, timeout=120)
                audio = resp.read()
                elapsed = time.time() - t0

                _state.log(f"[OK] → {url}  {len(audio):,}B  {elapsed:.2f}s")
                _state.record_ok()

                # 回传音频给客户端
                self.send_response(200)
                ct = resp.headers.get("Content-Type", "audio/wav")
                self.send_header("Content-Type", ct)
                self.send_header("Content-Length", str(len(audio)))
                self.send_header("X-Backend", url)
                self.end_headers()
                self.wfile.write(audio)
                return

            except urllib.error.HTTPError as e:
                err_body = e.read(200).decode(errors="replace")
                elapsed = time.time() - t0
                _state.log(f"[HTTP {e.code}] {url}  {elapsed:.2f}s  {err_body[:80]}")
                # 4xx 不重试（参数问题），直接回传
                if 400 <= e.code < 500:
                    _state.record_fail()
                    self.send_response(e.code)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(err_body.encode())
                    return
                # 5xx 换下一台

            except Exception as e:
                elapsed = time.time() - t0
                _state.log(f"[失败] {url}  {elapsed:.2f}s  {type(e).__name__}: {e}")
                # 网络错误，换下一台

        # 所有后端都失败了
        _state.log(f"[错误] 所有 {max_try} 个后端均失败")
        _state.record_fail()
        self._respond(502, b'{"error":"all backends failed"}')

    def _send_status(self):
        data = json.dumps({
            "running": True,
            "backends": _state.backends,
            "total_req": _state.total_req,
            "total_ok":  _state.total_ok,
            "total_fail":_state.total_fail,
        }, ensure_ascii=False).encode()
        self._respond(200, data, "application/json")

    def _send_backends(self):
        data = json.dumps(_state.backends, ensure_ascii=False).encode()
        self._respond(200, data, "application/json")

    def _not_found(self):
        self._respond(404, b'{"error":"not found"}')

    def _respond(self, code, body, ct="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class TTSProxyServer:
    """
    可嵌入 GUI 的代理服务封装。

    用法：
        proxy = TTSProxyServer(port=9882, config_path=..., log_cb=..., stats_cb=...)
        proxy.start()
        ...
        proxy.stop()
        proxy.reload_backends()
    """

    def __init__(self, port=9882, config_path=CONFIG_PATH,
                 log_cb=None, stats_cb=None):
        self.port = port
        self.config_path = config_path
        self._server: HTTPServer | None = None
        self._thread: threading.Thread | None = None
        self.running = False

        # 注册回调
        _state.log_cb   = log_cb
        _state.stats_cb = stats_cb

    def reload_backends(self):
        _state.reload(self.config_path)

    def start(self):
        if self.running:
            return
        _state.reload(self.config_path)
        _state.total_req = _state.total_ok = _state.total_fail = 0

        try:
            self._server = HTTPServer(("0.0.0.0", self.port), TTSProxyHandler)
        except OSError as e:
            _state.log(f"[错误] 端口 {self.port} 无法绑定: {e}")
            raise

        self.running = True
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()
        _state.log(f"[启动] 代理服务监听 0.0.0.0:{self.port}  /tts")
        _state.log(f"[提示] 将 TTS 客户端地址改为 http://127.0.0.1:{self.port}/tts 即可")

    def _serve(self):
        try:
            self._server.serve_forever()
        except Exception:
            pass

    def stop(self):
        if not self.running:
            return
        self.running = False
        if self._server:
            self._server.shutdown()
            self._server = None
        _state.log("[停止] 代理服务已关闭")

    @property
    def local_url(self):
        return f"http://127.0.0.1:{self.port}/tts"


# ── 命令行独立运行 ────────────────────────────────────────
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="TTS 代理服务器")
    parser.add_argument("--port",   type=int, default=9882, help="监听端口（默认9882）")
    parser.add_argument("--config", type=str, default=CONFIG_PATH, help="配置文件路径")
    args = parser.parse_args()

    proxy = TTSProxyServer(port=args.port, config_path=args.config)
    try:
        proxy.start()
        print(f"代理已启动，按 Ctrl+C 停止。", flush=True)
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        proxy.stop()
        print("已退出。")
