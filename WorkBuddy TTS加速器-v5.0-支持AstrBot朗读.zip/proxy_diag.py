"""代理诊断：启动代理 → 发请求 → 捕获报错"""
import sys, os, time, json, threading, traceback, urllib.request, urllib.error
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# 1. 导入代理模块，看有没有 import 错误
print("=== 1. 导入 tts_proxy ===")
try:
    import tts_proxy
    print("  导入成功")
except Exception as e:
    print(f"  导入失败: {e}")
    traceback.print_exc()
    sys.exit(1)

# 2. 启动代理
print("\n=== 2. 启动代理 ===")
def log_cb(msg): print(f"  [PROXY] {msg}")

try:
    proxy = tts_proxy.TTSProxyServer(port=19882, log_cb=log_cb)  # 用19882避免和现有冲突
    proxy.start()
    time.sleep(1)
    print(f"  代理运行状态: {proxy.running}")
    print(f"  已加载后端: {proxy.backends}")
except Exception as e:
    print(f"  启动失败: {e}")
    traceback.print_exc()
    sys.exit(1)

# 3. 读取角色配置
print("\n=== 3. 读取角色配置 ===")
cfg_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tts_gui_config.json")
with open(cfg_path, encoding='utf-8') as f:
    cfg = json.load(f)
role_cfg = cfg['roles'].get('可莉')
if not role_cfg:
    role_cfg = next(iter(cfg['roles'].values()))
print(f"  使用角色: {list(cfg['roles'].keys())[0]}")
print(f"  ref_audio: {role_cfg['ref_audio_path']}")

# 4. 发测试请求
print("\n=== 4. 发 TTS 请求到代理 ===")
payload = {
    "text": "你好，这是一个测试。今天天气不错呢！",
    "text_lang": role_cfg.get("text_lang", "zh"),
    "ref_audio_path": role_cfg["ref_audio_path"],
    "prompt_text": role_cfg["prompt_text"],
    "prompt_lang": role_cfg.get("prompt_lang", "zh"),
    "top_k": 5, "top_p": 1, "temperature": 1,
    "text_split_method": "cut5",
    "batch_size": 1, "batch_threshold": 0.75,
    "split_bucket": True, "return_fragment": False,
    "speed_factor": 1.0, "streaming_mode": False,
    "seed": -1, "parallel_infer": True,
    "repetition_penalty": 1.35, "aux_ref_audio_paths": []
}
data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
url = "http://127.0.0.1:19882/tts"
print(f"  → POST {url}")
print(f"  文本: {payload['text']}")

try:
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    r = urllib.request.urlopen(req, timeout=60)
    audio = r.read()
    print(f"  [OK] 返回 {len(audio):,} bytes")
    print(f"  X-Backend: {r.headers.get('X-Backend', '(无)')}")
    print(f"  X-Elapsed: {r.headers.get('X-Elapsed', '(无)')}")
except urllib.error.HTTPError as e:
    body = e.read(500).decode(errors='replace')
    print(f"  [!] HTTP {e.code}: {body}")
except Exception as e:
    print(f"  [!] 异常: {type(e).__name__}: {e}")
    traceback.print_exc()

# 5. 停止
proxy.stop()
print("\n=== 诊断完成 ===")
