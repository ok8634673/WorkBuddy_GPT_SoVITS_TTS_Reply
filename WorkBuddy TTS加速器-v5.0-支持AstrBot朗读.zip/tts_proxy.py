"""
TTS 代理服务器 (tts_proxy.py)
────────────────────────────────────────────
监听本地端口，接收标准 GPT-SoVITS /tts 请求。

【智能加速模式】
  - 接收完整文本请求
  - 自动拆句 → 多台服务器并发合成
  - 按序合并 WAV → 返回完整音频
  - 多客户端同时请求时，各自独立并发，充分利用所有服务器

【兼容模式】（透传，当请求已是单句时）
  - Round-robin 轮询负载均衡
  - 自动跳过禁用服务器
  - 单台失败自动切换下一台

用法：
  python tts_proxy.py [--port 9882] [--config tts_gui_config.json]
"""

import json
import os
import sys
import re
import io
import wave
import time
import threading
import urllib.request
import urllib.error
import itertools
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime

# ── 强制 UTF-8 输出 ──────────────────────────────────────
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tts_gui_config.json")
DEBUG_LOG   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tts_proxy_debug.log")

# 调试模式开关（可在运行时动态修改，或由 GUI 传入）
_debug_mode: bool = False

def set_debug_mode(enabled: bool):
    global _debug_mode
    _debug_mode = enabled
    ts = datetime.now().strftime("%H:%M:%S")
    msg = f"[{ts}] [调试] 调试模式已{'开启' if enabled else '关闭'}，日志写入: {DEBUG_LOG}\n"
    print(msg, end="", flush=True)
    with open(DEBUG_LOG, "a", encoding="utf-8") as f:
        f.write(msg)

def _debug_log(tag: str, payload: dict):
    """将请求 payload 写入调试日志"""
    if not _debug_mode:
        return
    ts = datetime.now().strftime("%H:%M:%S")
    try:
        with open(DEBUG_LOG, "a", encoding="utf-8") as f:
            f.write(f"\n{'='*60}\n")
            f.write(f"[{ts}] {tag}\n")
            f.write(json.dumps(payload, ensure_ascii=False, indent=2))
            f.write("\n")
            # 关键字段速览
            f.write("--- 关键字段 ---\n")
            for field in ["text", "text_lang", "ref_audio_path", "prompt_text",
                          "prompt_lang", "aux_ref_audio_path", "aux_ref_audio_paths",
                          "text_split_method", "speed_factor", "split_bucket",
                          "top_k", "streaming_mode"]:
                val = payload.get(field, "【缺失】")
                t = type(val).__name__ if val != "【缺失】" else "-"
                f.write(f"  {field}: [{t}] {repr(val)[:120]}\n")
            f.write(f"{'='*60}\n")
    except Exception as e:
        print(f"[调试日志写入失败] {e}", flush=True)


# ════════════════════════════════════════════════════════
#  工具函数
# ════════════════════════════════════════════════════════

def clean_text(text: str) -> str:
    """
    清理 TTS 文本，移除不应朗读的内容：
    - HTML 标签（<br>, <br/>, <p>, <b> 等）
    - HTML 实体（&nbsp; &amp; 等）
    - 多余的空白行
    """
    if not text:
        return text
    # <br> / <br/> / <BR> → 换行（保留语义，后续分句会处理）
    text = re.sub(r'<br\s*/?>', '\n', text, flags=re.IGNORECASE)
    # 其他 HTML 标签全部移除
    text = re.sub(r'<[^>]+>', '', text)
    # HTML 实体
    text = text.replace('&nbsp;', ' ').replace('&amp;', '&') \
               .replace('&lt;', '<').replace('&gt;', '>') \
               .replace('&quot;', '"').replace('&#39;', "'")
    # 收拢多余空白行
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def split_sentences(text: str) -> list[str]:
    """智能分句，与 tts_gui.py 保持一致"""
    if not text.strip():
        return []
    parts = re.split(r'(?<=[。！？…～\!\?])', text)
    parts = [p.strip() for p in parts if p.strip()]
    merged = []
    buf = ""
    for p in parts:
        buf += p
        if len(buf) >= 8:
            merged.append(buf)
            buf = ""
    if buf:
        if merged:
            merged[-1] += buf
        else:
            merged.append(buf)
    result = []
    for s in merged:
        if len(s) > 50:
            subs = re.split(r'(?<=[，,；;、])', s)
            subs = [x.strip() for x in subs if x.strip()]
            sub_buf = ""
            for sub in subs:
                sub_buf += sub
                if len(sub_buf) >= 15:
                    result.append(sub_buf)
                    sub_buf = ""
            if sub_buf:
                if result:
                    result[-1] += sub_buf
                else:
                    result.append(sub_buf)
        else:
            result.append(s)
    return result if result else [text]


def merge_wav_bytes(wav_list: list[bytes]) -> bytes | None:
    """将多段 WAV 字节流按顺序合并"""
    if not wav_list:
        return None
    if len(wav_list) == 1:
        return wav_list[0]
    frames_list = []
    params = None
    for wb in wav_list:
        try:
            with wave.open(io.BytesIO(wb), 'rb') as wf:
                if params is None:
                    params = wf.getparams()
                frames_list.append(wf.readframes(wf.getnframes()))
        except Exception:
            pass
    if not frames_list or params is None:
        return None
    out = io.BytesIO()
    with wave.open(out, 'wb') as wf:
        wf.setparams(params)
        for f in frames_list:
            wf.writeframes(f)
    return out.getvalue()


def load_backends(config_path=CONFIG_PATH) -> list[list[str]]:
    """
    从配置文件读取后端，返回分组列表（每组为一台物理机器的所有IP）。
    只返回 enabled 的组和IP。
    """
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        groups = []
        for grp in cfg.get("server_groups", []):
            if not grp.get("enabled", True):
                continue
            urls = []
            for u in grp.get("urls", []):
                url = u["url"] if isinstance(u, dict) else u
                en  = u.get("enabled", True) if isinstance(u, dict) else True
                if en:
                    urls.append(url)
            if urls:
                groups.append(urls)
        return groups
    except Exception:
        return []


def load_roles(config_path=CONFIG_PATH) -> dict:
    """从配置文件读取角色配置"""
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        return cfg.get("roles", {})
    except Exception:
        return {}


# ════════════════════════════════════════════════════════
#  全局状态
# ════════════════════════════════════════════════════════

class ProxyState:
    """代理服务全局状态，供 HTTPHandler 共享"""
    def __init__(self):
        self.server_groups: list[list[str]] = []   # 按机器分组
        self.roles: dict = {}                      # 角色配置缓存
        self.default_role: str | None = None       # 默认角色名（第一个）
        self.lock = threading.Lock()
        self._rr_group_idx = 0     # 全局 round-robin 组索引（跨请求共享！）
        self.total_req  = 0
        self.total_ok   = 0
        self.total_fail = 0
        self.log_cb   = None
        self.stats_cb = None
        # 每组当前并发数（用于最小负载调度）
        self._group_active: list[int] = []

    def reload(self, config_path=CONFIG_PATH):
        groups = load_backends(config_path)
        roles  = load_roles(config_path)
        with self.lock:
            self.server_groups = groups
            self.roles = roles
            self.default_role = next(iter(roles), None) if roles else None
            self._rr_group_idx = 0
            self._group_active = [0] * len(groups)
        flat = [u for g in groups for u in g]
        self._log(f"[配置] 已加载 {len(groups)} 组 / {len(flat)} 个后端  角色: {list(roles.keys())}")
        for i, g in enumerate(groups):
            self._log(f"  组{i+1}: {g}")

    # GPT-SoVITS 要求这些字段必须是 list 类型（含复数名）
    _LIST_FIELDS = {"aux_ref_audio_path", "aux_ref_audio_paths"}

    # GET URL 参数全部是字符串，需要按类型转换
    _INT_FIELDS   = {"top_k", "batch_size", "seed"}
    _FLOAT_FIELDS = {"top_p", "temperature", "speed_factor", "batch_threshold",
                     "fragment_interval", "repetition_penalty"}
    _BOOL_FIELDS  = {"split_bucket", "streaming_mode", "parallel_infer", "return_fragment"}

    def fill_role_fields(self, payload: dict) -> dict:
        """
        为缺少角色配置字段的请求自动补全（供第三方客户端兼容）。
        优先用请求里指定的 character/role/speaker 字段查找角色；
        找不到则用默认角色（配置里第一个）。
        只补全缺失字段，不覆盖已有字段。

        注意：GPT-SoVITS 要求 aux_ref_audio_path 必须是 list，
        会自动将字符串值转换为单元素列表。
        """
        ROLE_FIELDS = ("ref_audio_path", "prompt_text", "prompt_lang")
        # 已经有完整字段，不需要补全
        if all(payload.get(f) for f in ROLE_FIELDS):
            # 即便不补全，也要确保 list 字段类型正确
            return self._fix_list_fields(payload)

        with self.lock:
            roles = dict(self.roles)
            default = self.default_role

        if not roles:
            return self._fix_list_fields(payload)

        # 尝试从请求参数推断角色名
        role_name = None
        for key in ("character", "role", "speaker", "role_name", "char"):
            v = payload.get(key, "")
            if v and v in roles:
                role_name = v
                break

        if not role_name:
            role_name = default

        if not role_name or role_name not in roles:
            return self._fix_list_fields(payload)

        role_cfg = roles[role_name]
        result = dict(payload)
        # 只补缺失字段
        for f in ROLE_FIELDS:
            if not result.get(f):
                result[f] = role_cfg.get(f, "")
        # text_lang / text_split_method / speed_factor 等也补上
        for f in ("text_lang", "text_split_method", "speed_factor",
                  "prompt_lang", "top_k", "top_p", "temperature",
                  "batch_size", "split_bucket", "return_fragment",
                  "streaming_mode", "seed", "parallel_infer",
                  "repetition_penalty"):
            if f not in result and f in role_cfg:
                result[f] = role_cfg[f]
        # aux_ref_audio_path：若角色配置里有，加入列表
        if "aux_ref_audio_path" in role_cfg and "aux_ref_audio_path" not in result:
            v = role_cfg["aux_ref_audio_path"]
            result["aux_ref_audio_path"] = v if isinstance(v, list) else [v] if v else []

        self._log(f"[补全] 使用角色「{role_name}」补全缺失字段")
        return self._fix_list_fields(result)

    def _fix_list_fields(self, payload: dict) -> dict:
        """
        确保 GPT-SoVITS 要求为 list 的字段不是字符串类型。
        若字段值是字符串，自动包装为单元素列表；若是空字符串则移除。
        """
        result = dict(payload)
        for f in self._LIST_FIELDS:
            if f in result:
                v = result[f]
                if isinstance(v, str):
                    result[f] = [v] if v else []
                elif v is None:
                    del result[f]
        return result

    @property
    def all_backends_flat(self) -> list[str]:
        """所有后端展平列表"""
        with self.lock:
            return [u for g in self.server_groups for u in g]

    def next_group_rr(self) -> list[str] | None:
        """Round-robin 取下一个机器组（全局状态，跨请求）"""
        with self.lock:
            if not self.server_groups:
                return None
            g = self.server_groups[self._rr_group_idx % len(self.server_groups)]
            self._rr_group_idx += 1
            return g

    def alloc_groups_for_sentences(self, n_sentences: int) -> list[int]:
        """
        为 n_sentences 个句子分配组索引，保证：
        1. 句子尽量分散到不同组（利用所有机器）
        2. 基于全局 RR 偏移，跨请求错开，避免多客户端撞机
        返回每个句子应使用的 group_idx 列表
        """
        with self.lock:
            if not self.server_groups:
                return [0] * n_sentences
            n_groups = len(self.server_groups)
            base = self._rr_group_idx  # 本次请求的起始偏移
            self._rr_group_idx += n_sentences  # 全局偏移推进，下次请求会错开
            return [(base + i) % n_groups for i in range(n_sentences)]

    def _log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}"
        print(line, flush=True)
        if self.log_cb:
            try:
                self.log_cb(line)
            except Exception:
                pass

    def _update_stats(self):
        if self.stats_cb:
            try:
                self.stats_cb(self.total_req, self.total_ok, self.total_fail)
            except Exception:
                pass

    def log(self, msg):
        self._log(msg)

    def record_ok(self):
        self.total_ok += 1
        self._update_stats()

    def record_fail(self):
        self.total_fail += 1
        self._update_stats()

    def record_req(self):
        self.total_req += 1
        self._update_stats()


# 全局状态单例
_state = ProxyState()


# ════════════════════════════════════════════════════════
#  核心：并发合成引擎
# ════════════════════════════════════════════════════════

def _request_single(group_urls: list[str], payload: dict, timeout=90) -> tuple[bytes | None, str | None]:
    """向一组（同台机器的多IP）发请求，组内自动切换"""
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    for url in group_urls:
        try:
            req = urllib.request.Request(
                url, data=data,
                headers={"Content-Type": "application/json"}
            )
            r = urllib.request.urlopen(req, timeout=timeout)
            audio = r.read()
            if len(audio) > 100:
                return audio, url
        except urllib.error.HTTPError as e:
            err = e.read(100).decode(errors="replace")
            _state.log(f"[HTTP {e.code}] {url}  {err[:60]}")
            if 400 <= e.code < 500:
                return None, None   # 4xx 参数错误，不重试
        except Exception as e:
            _state.log(f"[网络失败] {url}  {type(e).__name__}: {e}")
    return None, None


def synthesize_parallel(payload_base: dict) -> tuple[bytes | None, str]:
    """
    智能并发合成：
      1. 从请求体提取 text，执行智能分句
      2. 无论几句，都基于全局 RR 偏移分配组，保证：
         - 单句请求：每次分配到不同组（多客户端轮流用不同机器）
         - 多句请求：各句并发分配到不同机器组
      3. 按序合并 WAV 返回
    返回 (wav_bytes, log_msg)
    """
    text = payload_base.get("text", "").strip()
    if not text:
        return None, "[错误] 请求体缺少 text 字段"

    with _state.lock:
        groups = list(_state.server_groups)

    if not groups:
        return None, "[错误] 无可用后端服务器"

    n_groups = len(groups)
    sentences = split_sentences(text)
    total = len(sentences)

    _state.log(f"[合成] {total}句 / {n_groups}组后端  文本: {text[:30]}{'…' if len(text)>30 else ''}")

    # 为每个句子分配组索引（全局 RR，跨请求错开）
    group_assignments = _state.alloc_groups_for_sentences(total)

    results: list[bytes | None] = [None] * total
    used_backends: list[str] = [""] * total
    lock = threading.Lock()

    def worker(idx: int, sentence: str, grp_idx: int):
        payload = dict(payload_base)
        payload["text"] = sentence
        payload["text_split_method"] = "cut0"   # 单句，禁止 GPT-SoVITS 内部再分
        t0 = time.time()
        group = groups[grp_idx]
        audio, used = _request_single(group, payload)
        elapsed = time.time() - t0
        with lock:
            if audio:
                results[idx] = audio
                used_backends[idx] = used or ""
                _state.log(f"[OK] 句{idx+1}/{total} {len(audio):,}B {elapsed:.2f}s ← {used}")
            else:
                _state.log(f"[--] 句{idx+1}/{total} 失败 ({elapsed:.2f}s)")

    # 全部句子同时并发（不再分批，让各机器真正同时工作）
    threads = [
        threading.Thread(target=worker, args=(i, s, group_assignments[i]), daemon=True)
        for i, s in enumerate(sentences)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # 失败重试（换下一组）
    for i, s in enumerate(sentences):
        if results[i] is None:
            _state.log(f"[重试] 句{i+1} 换组重试...")
            retry_grp = (group_assignments[i] + 1) % n_groups
            payload = dict(payload_base)
            payload["text"] = s
            payload["text_split_method"] = "cut0"
            audio, used = _request_single(groups[retry_grp], payload)
            if audio:
                results[i] = audio
                used_backends[i] = used or ""
                _state.log(f"[OK] 句{i+1} 重试成功 ← {used}")
            else:
                _state.log(f"[--] 句{i+1} 重试仍失败，跳过")

    valid = [r for r in results if r is not None]
    if not valid:
        return None, "[失败] 所有句子合成失败"

    if total == 1:
        # 单句直接返回，不需要合并
        return valid[0], used_backends[0] or ""

    wav_data = merge_wav_bytes(valid)
    if not wav_data:
        return None, "[失败] WAV 合并失败"

    backends_used = list(dict.fromkeys(b for b in used_backends if b))
    return wav_data, f"并发{total}句，后端: {backends_used}"


# ════════════════════════════════════════════════════════
#  HTTP 处理器
# ════════════════════════════════════════════════════════

# GET URL参数全是字符串，转换为 GPT-SoVITS 期望的正确类型
_PARAM_INT_FIELDS   = {"top_k", "batch_size", "seed"}
_PARAM_FLOAT_FIELDS = {"top_p", "temperature", "speed_factor", "batch_threshold",
                       "fragment_interval", "repetition_penalty"}
_PARAM_BOOL_FIELDS  = {"split_bucket", "streaming_mode", "parallel_infer", "return_fragment"}
# 这些字段服务端要求 list；GET 参数里空字符串 → []，非空字符串 → [value]
_PARAM_LIST_FIELDS  = {"aux_ref_audio_path", "aux_ref_audio_paths"}

def _fix_param_types(payload: dict) -> dict:
    """将 GET URL 参数从字符串转换为正确的 Python 类型"""
    result = {}
    for k, v in payload.items():
        if k in _PARAM_LIST_FIELDS:
            # 列表字段：空字符串→[]，否则包装成列表
            if isinstance(v, list):
                result[k] = v
            elif isinstance(v, str):
                result[k] = [v] if v.strip() else []
            else:
                result[k] = v
        elif k in _PARAM_INT_FIELDS:
            try:
                result[k] = int(v)
            except (ValueError, TypeError):
                result[k] = v
        elif k in _PARAM_FLOAT_FIELDS:
            try:
                result[k] = float(v)
            except (ValueError, TypeError):
                result[k] = v
        elif k in _PARAM_BOOL_FIELDS:
            if isinstance(v, str):
                result[k] = v.lower() not in ("false", "0", "no", "")
            else:
                result[k] = bool(v)
        else:
            result[k] = v
    return result

class TTSProxyHandler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass  # 屏蔽默认 access log

    def do_GET(self):
        path = self.path.split("?")[0].rstrip("/")
        if path == "/status":
            self._send_status()
        elif path == "/backends":
            self._send_backends()
        elif path in ("", "/health"):
            self._respond(200, b'{"status":"ok"}')
        elif path == "/tts":
            # 第三方客户端用 GET + URL参数 的形式调用
            self._handle_tts(method="GET")
        else:
            self._not_found()

    def do_POST(self):
        if self.path.split("?")[0].rstrip("/") == "/tts":
            self._handle_tts(method="POST")
        else:
            self._not_found()

    def _handle_tts(self, method="POST"):
        _state.record_req()

        # ── 解析请求参数（兼容 GET URL参数 和 POST JSON body）──────
        payload = {}
        raw_body = b""

        if method == "GET":
            # GET /tts?text=xxx&ref_audio_path=yyy&...
            from urllib.parse import urlparse, parse_qs
            qs = parse_qs(urlparse(self.path).query, keep_blank_values=True)
            for k, v in qs.items():
                payload[k] = v[0] if len(v) == 1 else v
            raw_body = None  # GET没有body
            # GET 参数全是字符串，转换为正确类型
            payload = _fix_param_types(payload)
        else:
            # POST：优先读JSON body，同时也合并URL参数（部分客户端混用）
            length = int(self.headers.get("Content-Length", 0))
            raw_body = self.rfile.read(length) if length > 0 else b""
            # 先尝试JSON
            if raw_body:
                try:
                    payload = json.loads(raw_body.decode("utf-8"))
                except Exception:
                    # JSON解析失败：尝试 form-urlencoded
                    try:
                        from urllib.parse import parse_qs
                        qs = parse_qs(raw_body.decode("utf-8"), keep_blank_values=True)
                        for k, v in qs.items():
                            payload[k] = v[0] if len(v) == 1 else v
                    except Exception:
                        pass
            # 合并URL参数（优先级低于body）
            if "?" in self.path:
                from urllib.parse import urlparse, parse_qs
                qs = parse_qs(urlparse(self.path).query, keep_blank_values=True)
                for k, v in qs.items():
                    payload.setdefault(k, v[0] if len(v) == 1 else v)

        # ── 检查是否有 text 字段 ──────────────────────────────────
        text = payload.get("text", "").strip() if payload else ""

        if not text:
            # text为空：不自己处理，原样透传给后端（让后端返回它自己的错误）
            _state.log(f"[透传] 请求无text字段，原样转发到后端")
            _debug_log("透传请求（无text）", payload)
            self._passthrough(method, raw_body)
            return

        # ── 清理 text 中的 HTML 标签等 ───────────────────────────
        text_clean = clean_text(text)
        if text_clean != text:
            _state.log(f"[清理] text 含HTML标签，已清理: {repr(text[:60])} → {repr(text_clean[:60])}")
        payload["text"] = text_clean

        # ── 调试日志（解析后、补全前）───────────────────────────
        _debug_log(f"收到请求 ({method}) 解析后", payload)

        # ── 有text：走加速并发流程 ────────────────────────────────
        # 自动补全缺失的角色配置字段（兼容第三方客户端）
        payload = _state.fill_role_fields(payload)

        # ── 调试日志（补全后、发送前）───────────────────────────
        _debug_log("补全角色字段后（即将发往后端）", payload)

        t0 = time.time()
        wav_data, info = synthesize_parallel(payload)
        elapsed = time.time() - t0

        if wav_data is None:
            _state.log(f"[错误] {info}  ({elapsed:.2f}s)")
            _state.record_fail()
            self._respond(502, json.dumps({"error": info}).encode())
            return

        _state.log(f"[完成] {len(wav_data):,}B  {elapsed:.2f}s  {info}")
        _state.record_ok()

        safe_info = info.encode('ascii', errors='replace').decode('ascii')[:120]

        self.send_response(200)
        self.send_header("Content-Type", "audio/wav")
        self.send_header("Content-Length", str(len(wav_data)))
        self.send_header("X-Backend", safe_info)
        self.send_header("X-Elapsed", f"{elapsed:.2f}s")
        self.end_headers()
        self.wfile.write(wav_data)

    def _passthrough(self, method, raw_body):
        """原样把请求转发给第一个可用后端，透传响应"""
        with _state.lock:
            groups = list(_state.server_groups)
        if not groups:
            _state.record_fail()
            self._respond(502, b'{"error":"no backend available"}')
            return

        # 取第一个可用组的第一个URL
        target_url = None
        for g in groups:
            if g:
                target_url = g[0]
                break
        if not target_url:
            _state.record_fail()
            self._respond(502, b'{"error":"no backend available"}')
            return

        # 拼接原始path（含URL参数）到目标URL
        from urllib.parse import urlparse
        parsed = urlparse(target_url)
        fwd_path = self.path  # 保留原始path+query
        fwd_url = f"{parsed.scheme}://{parsed.netloc}{fwd_path}"

        try:
            headers = {"Content-Type": self.headers.get("Content-Type", "application/json")}
            if method == "GET":
                req = urllib.request.Request(fwd_url, headers=headers, method="GET")
            else:
                req = urllib.request.Request(fwd_url, data=raw_body, headers=headers, method="POST")

            resp = urllib.request.urlopen(req, timeout=90)
            body = resp.read()
            _state.record_ok()
            ct = resp.headers.get("Content-Type", "application/octet-stream")
            self.send_response(resp.status)
            self.send_header("Content-Type", ct)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except urllib.error.HTTPError as e:
            body = e.read()
            _state.record_fail()
            self.send_response(e.code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            _state.record_fail()
            _state.log(f"[透传失败] {fwd_url}  {type(e).__name__}: {e}")
            self._respond(502, json.dumps({"error": str(e)}).encode())

    def _send_status(self):
        flat = _state.all_backends_flat
        data = json.dumps({
            "running": True,
            "groups":  len(_state.server_groups),
            "backends": flat,
            "total_req":  _state.total_req,
            "total_ok":   _state.total_ok,
            "total_fail": _state.total_fail,
        }, ensure_ascii=False).encode()
        self._respond(200, data, "application/json")

    def _send_backends(self):
        data = json.dumps(_state.all_backends_flat, ensure_ascii=False).encode()
        self._respond(200, data, "application/json")

    def _not_found(self):
        self._respond(404, b'{"error":"not found"}')

    def _respond(self, code, body, ct="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


# ════════════════════════════════════════════════════════
#  TTSProxyServer 封装（供 GUI 嵌入）
# ════════════════════════════════════════════════════════

class TTSProxyServer:
    """
    可嵌入 GUI 的代理服务封装，支持双端口模式：

    ┌─────────────────────────────────────────────────────────────────┐
    │  proxy_port (默认 9882)  —— 加速器互联通讯端口                    │
    │    · 代理服务器模式：对外暴露，供客户端机器的加速器 GUI 填写        │
    │    · 客户端模式：连接对方的 proxy_port                            │
    │                                                                  │
    │  tts_port   (默认 9880)  —— 本机 TTS 监听端口（可选）             │
    │    · 仅代理服务器模式下可开启                                      │
    │    · tts_reply.py / 本地应用 填这个端口即可，不受加速器互联影响    │
    └─────────────────────────────────────────────────────────────────┘

    用法：
        proxy = TTSProxyServer(port=9882, tts_port=9880, config_path=..., log_cb=..., stats_cb=...)
        proxy.start()          # 同时启动两个监听
        proxy.reload_backends()
        proxy.stop()           # 同时关闭两个监听
    """

    def __init__(self, port=9882, tts_port=None, config_path=CONFIG_PATH,
                 log_cb=None, stats_cb=None):
        self.port      = port       # 加速器互联端口（固定，对外暴露）
        self.tts_port  = tts_port   # 本机 TTS 监听端口（可选，None 表示不启用）
        self.config_path = config_path
        self._server: HTTPServer | None = None       # 互联端口 server
        self._tts_server: HTTPServer | None = None   # TTS 监听端口 server
        self._thread: threading.Thread | None = None
        self._tts_thread: threading.Thread | None = None
        self.running = False
        _state.log_cb   = log_cb
        _state.stats_cb = stats_cb

    def reload_backends(self):
        _state.reload(self.config_path)

    @property
    def backends(self) -> list[str]:
        return _state.all_backends_flat

    @property
    def groups(self) -> list[list[str]]:
        return list(_state.server_groups)

    def start(self):
        if self.running:
            return
        _state.reload(self.config_path)
        _state.total_req = _state.total_ok = _state.total_fail = 0

        # ── 启动互联通讯端口（proxy_port）──────────────────────
        try:
            self._server = HTTPServer(("0.0.0.0", self.port), TTSProxyHandler)
        except OSError as e:
            _state.log(f"[错误] 互联端口 {self.port} 无法绑定: {e}")
            raise

        self.running = True
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()
        _state.log(f"[启动] 互联通讯端口 0.0.0.0:{self.port}  /tts  （供其他加速器连接）")

        # ── 启动本机 TTS 监听端口（tts_port，可选）──────────────
        if self.tts_port and self.tts_port != self.port:
            try:
                self._tts_server = HTTPServer(("0.0.0.0", self.tts_port), TTSProxyHandler)
                self._tts_thread = threading.Thread(target=self._serve_tts, daemon=True)
                self._tts_thread.start()
                _state.log(f"[启动] 本机TTS监听端口 0.0.0.0:{self.tts_port}  /tts  （供 tts_reply.py 连接）")
            except OSError as e:
                _state.log(f"[警告] TTS监听端口 {self.tts_port} 绑定失败（可继续使用互联端口）: {e}")
                self._tts_server = None

        _state.log(f"[模式] 智能并发加速 — 自动拆句 → 多服务器并发 → 合并返回")

    def _serve(self):
        try:
            self._server.serve_forever()
        except Exception:
            pass

    def _serve_tts(self):
        try:
            self._tts_server.serve_forever()
        except Exception:
            pass

    def stop(self):
        if not self.running:
            return
        self.running = False
        if self._tts_server:
            self._tts_server.shutdown()
            self._tts_server = None
        if self._server:
            self._server.shutdown()
            self._server = None
        _state.log("[停止] 代理服务已全部关闭")

    @property
    def local_url(self):
        return f"http://127.0.0.1:{self.port}/tts"

    @property
    def local_tts_url(self):
        if self.tts_port:
            return f"http://127.0.0.1:{self.tts_port}/tts"
        return self.local_url


# ════════════════════════════════════════════════════════
#  命令行独立运行
# ════════════════════════════════════════════════════════
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="TTS 代理服务器（智能并发加速版）")
    parser.add_argument("--port",   type=int, default=9882)
    parser.add_argument("--config", type=str, default=CONFIG_PATH)
    args = parser.parse_args()

    proxy = TTSProxyServer(port=args.port, config_path=args.config)
    try:
        proxy.start()
        print(f"代理已启动，按 Ctrl+C 停止。", flush=True)
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        proxy.stop()
        print("已退出。")
