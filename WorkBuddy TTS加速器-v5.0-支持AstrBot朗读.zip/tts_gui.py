"""
TTS 加速器 配置与测试 GUI
功能：
  - 角色管理（增删改、语言/cut方法/语速配置）
  - 服务器管理（增删改、拖拽排序、在线检测）
  - 全局设置（生成路径、并行触发阈值）
  - 配置导入/导出（JSON）
  - 测试播放（实时日志）
  - 兼容 Windows / Linux 路径
"""

import sys, os, re, io, json, wave, threading, platform, subprocess, shutil, socket
import urllib.request, urllib.error
from datetime import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

# ── 平台 ──────────────────────────────────────────────────
IS_WIN = platform.system() == "Windows"

# ── 默认配置 ─────────────────────────────────────────────
DEFAULT_CONFIG = {
    "version": "2.0",
    "audio_dir": r"G:\WorkBuddy\generated_audio" if IS_WIN else "/home/terrence/Desktop/openclaw/generated_audio",
    "parallel_threshold": 2,          # 句数 >= 此值时触发并行
    # ── 运行模式 ──────────────────────────────────────────
    # "proxy_server" : 本机作为代理服务器（启动9882，接受客户端请求，并发调度后端）
    # "proxy_client" : 本机作为客户端（连接远程代理，不直连TTS服务器）
    # "direct"       : 直连模式（旧版行为，tts_reply.py 自己管并发）
    "mode": "proxy_server",
    "client": {
        "proxy_url": "http://192.168.28.3:9882/tts",   # 客户端模式时连接的代理地址
    },
    "server_groups": [
        {
            "name": "笔记本（首选）",
            "enabled": True,
            "urls": [
                {"url": "http://192.168.28.3:9880/tts",   "enabled": True},
                {"url": "http://192.168.31.5:9880/tts",   "enabled": True},
                {"url": "http://192.168.28.7:9880/tts",   "enabled": True},
            ]
        },
        {
            "name": "华硕主机（备选）",
            "enabled": True,
            "urls": [
                {"url": "http://192.168.31.177:9880/tts", "enabled": True},
                {"url": "http://192.168.28.2:9880/tts",   "enabled": True},
                {"url": "http://192.168.28.127:9880/tts", "enabled": True},
            ]
        }
    ],
    "proxy": {
        "enabled": False,
        "port": 9882,           # 加速器互联通讯端口（两台加速器之间用这个互联）
        "tts_port": 9880,       # 本机 TTS 监听端口（tts_reply.py 填这个，默认关闭）
        "tts_port_enabled": False,  # 是否同时开启本机 TTS 监听端口
        "auto_start": False,
    },
    "roles": {
        "可莉": {
            "ref_audio_path": "audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
            "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
            "prompt_lang": "zh",
            "text_lang": "zh",
            "text_split_method": "cut5",
            "speed_factor": 1.0,
        },
        "瑶瑶": {
            "ref_audio_path": "audio/yaoyao-甘雨姐姐，你没事吧？要不要喝点水，或者吃点别的什么调节一下？.wav",
            "prompt_text": "甘雨姐姐，你没事吧？要不要喝点水，或者吃点别的什么调节一下？",
            "prompt_lang": "zh",
            "text_lang": "auto",
            "text_split_method": "cut5",
            "speed_factor": 1.0,
        },
        "纳西妲": {
            "ref_audio_path": "audio/nahida-如果是说踏鞴砂那个神秘事件与倾奇者之类的.wav",
            "prompt_text": "如果是说踏鞴砂那个神秘事件与倾奇者之类的",
            "prompt_lang": "zh",
            "text_lang": "zh",
            "text_split_method": "cut5",
            "speed_factor": 0.85,
        },
    }
}

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tts_gui_config.json")

LANG_OPTIONS = [
    ("中文",   "zh"),
    ("英文",   "en"),
    ("日语",   "ja"),
    ("粤语",   "yue"),
    ("自动",   "auto"),
]
CUT_OPTIONS = [
    ("cut0 - 不切分",           "cut0"),
    ("cut1 - 按句号切",         "cut1"),
    ("cut2 - 每50字切一次",     "cut2"),
    ("cut3 - 按中文句号切",     "cut3"),
    ("cut4 - 按标点切（均衡）", "cut4"),
    ("cut5 - 按标点切（自然）", "cut5"),
]

# ════════════════════════════════════════════════════════
#  TTS 核心逻辑（独立于 GUI，可被脚本复用）
# ════════════════════════════════════════════════════════

def split_sentences(text):
    if not text.strip():
        return []
    parts = re.split(r'(?<=[。！？…～\!\?])', text)
    parts = [p.strip() for p in parts if p.strip()]
    merged = []
    buf = ""
    for p in parts:
        buf += p
        if len(buf) >= 8:
            merged.append(buf); buf = ""
    if buf:
        if merged:
            merged[-1] += buf
        else:
            merged.append(buf)
    result = []
    for s in merged:
        if len(s) > 50:
            subs = re.split(r'(?<=[，,；;、])', s)
            subs = [x.strip() for x in subs if x.strip()]
            sub_buf = ""
            for sub in subs:
                sub_buf += sub
                if len(sub_buf) >= 15:
                    result.append(sub_buf); sub_buf = ""
            if sub_buf:
                if result: result[-1] += sub_buf
                else: result.append(sub_buf)
        else:
            result.append(s)
    return result if result else [text]

def build_payload(role_cfg, text):
    return {
        "text": text,
        "text_lang": role_cfg.get("text_lang", "zh"),
        "ref_audio_path": role_cfg["ref_audio_path"],
        "prompt_text": role_cfg["prompt_text"],
        "prompt_lang": role_cfg["prompt_lang"],
        "top_k": 5, "top_p": 1, "temperature": 1,
        "text_split_method": role_cfg.get("text_split_method", "cut5"),
        "batch_size": 1, "batch_threshold": 0.75,
        "split_bucket": True, "return_fragment": False,
        "speed_factor": role_cfg.get("speed_factor", 1.0),
        "streaming_mode": False, "seed": -1,
        "parallel_infer": True, "repetition_penalty": 1.35,
        "aux_ref_audio_paths": []
    }

def request_tts(urls, payload, timeout=60):
    data = json.dumps(payload).encode("utf-8")
    for url in urls:
        try:
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
            r = urllib.request.urlopen(req, timeout=timeout)
            audio = r.read()
            if len(audio) > 100:
                return audio, url
        except urllib.error.HTTPError as e:
            pass
        except Exception:
            pass
    return None, None

def merge_wav_bytes(wav_list):
    if not wav_list: return None
    if len(wav_list) == 1: return wav_list[0]
    frames_list = []; params = None
    for wb in wav_list:
        try:
            with wave.open(io.BytesIO(wb), 'rb') as wf:
                if params is None: params = wf.getparams()
                frames_list.append(wf.readframes(wf.getnframes()))
        except: pass
    if not frames_list or params is None: return None
    out = io.BytesIO()
    with wave.open(out, 'wb') as wf:
        wf.setparams(params)
        for f in frames_list: wf.writeframes(f)
    return out.getvalue()

def play_wav(path):
    """跨平台播放 WAV"""
    if IS_WIN:
        import winsound
        winsound.PlaySound(path, winsound.SND_FILENAME)
    elif shutil.which("aplay"):
        subprocess.run(["aplay", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    elif shutil.which("paplay"):
        subprocess.run(["paplay", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        os.startfile(path) if hasattr(os, "startfile") else None

def check_server(url, timeout=5):
    try:
        req = urllib.request.Request(url, data=b'{}', headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=timeout)
        return True, "在线"
    except urllib.error.HTTPError as e:
        return True, f"在线 (HTTP {e.code})"
    except Exception as e:
        return False, f"离线 ({type(e).__name__})"

# ════════════════════════════════════════════════════════
#  配置加载/保存
# ════════════════════════════════════════════════════════

def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            # 合并缺失字段
            for k, v in DEFAULT_CONFIG.items():
                cfg.setdefault(k, v)
            # 兼容旧格式：urls为字符串列表 → 升级为对象列表
            for grp in cfg.get("server_groups", []):
                grp.setdefault("enabled", True)
                new_urls = []
                for u in grp.get("urls", []):
                    if isinstance(u, str):
                        new_urls.append({"url": u, "enabled": True})
                    else:
                        u.setdefault("enabled", True)
                        new_urls.append(u)
                grp["urls"] = new_urls
            # 兼容旧格式：无 mode / client 字段
            cfg.setdefault("mode", "proxy_server")
            cfg.setdefault("client", {"proxy_url": "http://192.168.28.3:9882/tts"})
            # 兼容旧格式：proxy 缺少字段时补默认值
            proxy_cfg = cfg.setdefault("proxy", {})
            proxy_cfg.setdefault("tts_port", 9880)
            proxy_cfg.setdefault("tts_port_enabled", False)
            proxy_cfg.setdefault("debug_mode", False)
            return cfg
        except: pass
    import copy
    return copy.deepcopy(DEFAULT_CONFIG)

def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

# ════════════════════════════════════════════════════════
#  主 GUI
# ════════════════════════════════════════════════════════

class TTSConfigApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TTS 加速器 配置工具 v2.0")
        self.geometry("980x720")
        self.minsize(800, 600)
        self.configure(bg="#1e1e2e")
        self.cfg = load_config()
        self._proxy = None          # TTSProxyServer 实例
        self._build_style()
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        # 自动启动代理
        if self.cfg.get("proxy", {}).get("auto_start", False):
            self.after(800, self._proxy_start)

    # ── 主题 ──────────────────────────────────────────
    def _build_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        BG   = "#1e1e2e"
        FG   = "#cdd6f4"
        SEL  = "#313244"
        ACC  = "#89b4fa"
        BTN  = "#313244"
        BTNF = "#cdd6f4"
        RED  = "#f38ba8"
        GRN  = "#a6e3a1"
        YEL  = "#f9e2af"

        style.configure(".",         background=BG, foreground=FG, font=("Microsoft YaHei UI", 10))
        style.configure("TFrame",    background=BG)
        style.configure("TLabel",    background=BG, foreground=FG)
        style.configure("TEntry",    fieldbackground=SEL, foreground=FG, insertcolor=FG, borderwidth=1)
        style.configure("TCombobox", fieldbackground=SEL, foreground=FG, selectbackground=SEL,
                        selectforeground=FG, arrowcolor=ACC)
        style.map("TCombobox", fieldbackground=[("readonly", SEL)], foreground=[("readonly", FG)])
        style.configure("TNotebook",        background=BG, borderwidth=0)
        style.configure("TNotebook.Tab",    background=BTN, foreground=BTNF, padding=[14,6],
                        font=("Microsoft YaHei UI", 10, "bold"))
        style.map("TNotebook.Tab",          background=[("selected", ACC)], foreground=[("selected", BG)])
        style.configure("TButton",          background=BTN, foreground=BTNF, padding=[10,5], borderwidth=0)
        style.map("TButton",                background=[("active", ACC)], foreground=[("active", BG)])
        style.configure("Accent.TButton",   background=ACC, foreground=BG, padding=[10,5], borderwidth=0,
                        font=("Microsoft YaHei UI", 10, "bold"))
        style.map("Accent.TButton",         background=[("active", "#74c7ec")])
        style.configure("Danger.TButton",   background=RED, foreground=BG, padding=[10,5], borderwidth=0)
        style.map("Danger.TButton",         background=[("active", "#eba0ac")])
        style.configure("Success.TButton",  background=GRN, foreground=BG, padding=[10,5], borderwidth=0)
        style.map("Success.TButton",        background=[("active", "#94e2d5")])
        style.configure("TLabelframe",      background=BG, foreground=ACC, bordercolor=SEL)
        style.configure("TLabelframe.Label",background=BG, foreground=ACC,
                        font=("Microsoft YaHei UI", 10, "bold"))
        style.configure("Treeview",         background=SEL, foreground=FG, fieldbackground=SEL,
                        rowheight=28, borderwidth=0)
        style.map("Treeview",               background=[("selected", ACC)], foreground=[("selected", BG)])
        style.configure("Treeview.Heading", background=BTN, foreground=ACC,
                        font=("Microsoft YaHei UI", 10, "bold"))
        style.configure("TScrollbar",       background=SEL, troughcolor=BG, arrowcolor=ACC)
        style.configure("TScale",           background=BG, troughcolor=SEL)
        style.configure("TSeparator",       background=SEL)

        self.colors = {"BG": BG, "FG": FG, "SEL": SEL, "ACC": ACC,
                       "RED": RED, "GRN": GRN, "YEL": YEL, "BTN": BTN}

    # ── 主布局 ────────────────────────────────────────
    def _build_ui(self):
        top = ttk.Frame(self); top.pack(fill="x", padx=12, pady=(10,0))
        ttk.Label(top, text="🎵 TTS 加速器 配置工具",
                  font=("Microsoft YaHei UI", 14, "bold"),
                  foreground=self.colors["ACC"]).pack(side="left")
        ttk.Button(top, text="💾 保存配置", style="Accent.TButton",
                   command=self._save).pack(side="right", padx=4)
        ttk.Button(top, text="📤 导出", command=self._export).pack(side="right", padx=4)
        ttk.Button(top, text="📥 导入", command=self._import).pack(side="right", padx=4)

        nb = ttk.Notebook(self); nb.pack(fill="both", expand=True, padx=12, pady=8)
        self.nb = nb

        self.tab_global  = ttk.Frame(nb); nb.add(self.tab_global,  text="⚙️  全局设置")
        self.tab_roles   = ttk.Frame(nb); nb.add(self.tab_roles,   text="🎭  角色管理")
        self.tab_servers = ttk.Frame(nb); nb.add(self.tab_servers, text="🖥️  服务器管理")
        self.tab_proxy   = ttk.Frame(nb); nb.add(self.tab_proxy,   text="🔀  代理服务")
        self.tab_test    = ttk.Frame(nb); nb.add(self.tab_test,    text="▶️  测试播放")

        self._build_global_tab()
        self._build_roles_tab()
        self._build_servers_tab()
        self._build_proxy_tab()
        self._build_test_tab()

    # ════════════════════════════════════════════════
    #  标签页：全局设置
    # ════════════════════════════════════════════════
    def _build_global_tab(self):
        f = self.tab_global
        pad = {"padx": 16, "pady": 8}

        # ── 运行模式 ──────────────────────────────
        mode_lf = ttk.LabelFrame(f, text="运行模式", padding=16)
        mode_lf.pack(fill="x", padx=16, pady=(16, 6))

        self.v_mode = tk.StringVar(value=self.cfg.get("mode", "proxy_server"))

        modes = [
            ("proxy_server", "🖥️  代理服务器模式",
             "本机启动代理服务（9882），自动拆句并发调度所有TTS服务器，\n"
             "其他机器的 tts_reply.py 指向本机IP:9882 即可享受加速。"),
            ("proxy_client", "💻  客户端模式",
             "本机连接远程代理服务器，不直连TTS服务器，\n"
             "所有合成请求发给代理机，由代理负责调度加速。"),
            ("direct",       "⚡  直连模式（兼容旧版）",
             "tts_reply.py 直接管理并发，多台客户端各自独立调度，\n"
             "适合单机使用。多机部署时推荐改用代理模式。"),
        ]

        self._mode_desc_labels = {}
        for val, label, desc in modes:
            row_f = ttk.Frame(mode_lf)
            row_f.pack(fill="x", pady=3)
            rb = ttk.Radiobutton(row_f, text=label, variable=self.v_mode, value=val,
                                 command=self._on_mode_change)
            rb.pack(side="left", padx=(0, 8))
            ttk.Label(row_f, text=desc, foreground="#6c7086",
                      justify="left", font=("Microsoft YaHei UI", 9)).pack(side="left")

        # 客户端模式：代理地址配置
        self.client_lf = ttk.LabelFrame(f, text="客户端模式 — 代理服务器地址", padding=14)
        self.client_lf.pack(fill="x", padx=16, pady=(0, 6))

        ttk.Label(self.client_lf, text="代理地址（/tts）：").grid(
            row=0, column=0, sticky="w", padx=8, pady=6)
        self.v_client_proxy_url = tk.StringVar(
            value=self.cfg.get("client", {}).get("proxy_url", "http://192.168.28.3:9882/tts"))
        proxy_entry = ttk.Entry(self.client_lf, textvariable=self.v_client_proxy_url, width=44)
        proxy_entry.grid(row=0, column=1, sticky="ew", padx=8, pady=6)
        ttk.Button(self.client_lf, text="测试连通", style="Accent.TButton",
                   command=self._test_client_proxy).grid(row=0, column=2, padx=8)
        self.client_lf.columnconfigure(1, weight=1)

        # ── 路径 & 并行设置 ───────────────────────
        lf = ttk.LabelFrame(f, text="生成路径 & 并行设置", padding=16)
        lf.pack(fill="x", padx=16, pady=6)

        ttk.Label(lf, text="音频输出目录：").grid(row=0, column=0, sticky="w", **pad)
        self.v_audio_dir = tk.StringVar(value=self.cfg.get("audio_dir", ""))
        e = ttk.Entry(lf, textvariable=self.v_audio_dir, width=52)
        e.grid(row=0, column=1, sticky="ew", **pad)
        ttk.Button(lf, text="浏览…", command=lambda: self._browse_dir(self.v_audio_dir)
                   ).grid(row=0, column=2, **pad)

        ttk.Label(lf, text="并行触发阈值（句数 ≥ N 时启用并行）：").grid(row=1, column=0, sticky="w", **pad)
        self.v_threshold = tk.IntVar(value=self.cfg.get("parallel_threshold", 2))
        sf = ttk.Frame(lf); sf.grid(row=1, column=1, sticky="w", **pad)
        ttk.Spinbox(sf, from_=1, to=20, textvariable=self.v_threshold, width=6,
                    font=("Microsoft YaHei UI", 11)).pack(side="left")
        ttk.Label(sf, text="  句（建议 2~3）", foreground="#6c7086").pack(side="left")
        lf.columnconfigure(1, weight=1)

        lf2 = ttk.LabelFrame(f, text="说明", padding=16)
        lf2.pack(fill="x", padx=16, pady=(0,16))
        tips = (
            "• 代理服务器模式：本机作为调度中心，其他客户端只需填代理地址，无需关心服务器列表\n"
            "• 客户端模式：填写代理机的IP:9882，多台客户端同时请求时代理自动分配服务器\n"
            "• 直连模式：兼容旧版行为，tts_reply.py 自己管并发（多机部署时加速效果会打折）\n"
            "• 生成路径支持 Windows（G:\\...）和 Linux（/home/...）路径"
        )
        ttk.Label(lf2, text=tips, foreground="#6c7086", justify="left").pack(anchor="w")

        # 初始化显隐
        self._on_mode_change()

    def _on_mode_change(self):
        """根据模式切换客户端配置区显隐"""
        mode = self.v_mode.get()
        if mode == "proxy_client":
            self.client_lf.pack(fill="x", padx=16, pady=(0, 6))
        else:
            self.client_lf.pack_forget()

    def _test_client_proxy(self):
        """测试客户端代理连通性"""
        url = self.v_client_proxy_url.get().strip()
        # 把 /tts 换成 /status
        status_url = url.rsplit("/tts", 1)[0] + "/status"
        def _check():
            try:
                r = urllib.request.urlopen(status_url, timeout=5)
                d = json.loads(r.read())
                self._log_msg(f"[代理测试] 连通！后端数: {len(d.get('backends', []))}  "
                              f"总请求: {d.get('total_req', 0)}")
            except Exception as e:
                self._log_msg(f"[代理测试] 失败: {e}")
        threading.Thread(target=_check, daemon=True).start()
        self.nb.select(self.tab_test)  # 跳到测试页看日志

    # ════════════════════════════════════════════════
    #  标签页：角色管理
    # ════════════════════════════════════════════════
    def _build_roles_tab(self):
        f = self.tab_roles
        left = ttk.Frame(f, width=180); left.pack(side="left", fill="y", padx=(12,0), pady=12)
        left.pack_propagate(False)

        ttk.Label(left, text="角色列表", font=("Microsoft YaHei UI", 10, "bold"),
                  foreground=self.colors["ACC"]).pack(pady=(0,6))

        lb_frame = ttk.Frame(left); lb_frame.pack(fill="both", expand=True)
        sb = ttk.Scrollbar(lb_frame); sb.pack(side="right", fill="y")
        self.role_listbox = tk.Listbox(lb_frame, yscrollcommand=sb.set,
                                        bg=self.colors["SEL"], fg=self.colors["FG"],
                                        selectbackground=self.colors["ACC"],
                                        selectforeground=self.colors["BG"],
                                        font=("Microsoft YaHei UI", 11),
                                        borderwidth=0, highlightthickness=0, activestyle="none")
        self.role_listbox.pack(fill="both", expand=True)
        sb.config(command=self.role_listbox.yview)
        self.role_listbox.bind("<<ListboxSelect>>", self._on_role_select)

        btn_row = ttk.Frame(left); btn_row.pack(fill="x", pady=6)
        ttk.Button(btn_row, text="＋ 新增", style="Success.TButton",
                   command=self._role_add).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(btn_row, text="✕ 删除", style="Danger.TButton",
                   command=self._role_delete).pack(side="left", expand=True, fill="x", padx=2)

        sep = ttk.Separator(f, orient="vertical"); sep.pack(side="left", fill="y", pady=12, padx=8)

        right = ttk.Frame(f); right.pack(side="left", fill="both", expand=True, padx=8, pady=12)
        self._build_role_detail(right)
        self._refresh_role_list()

    def _build_role_detail(self, parent):
        self.role_detail = parent
        lf = ttk.LabelFrame(parent, text="角色详情", padding=16)
        lf.pack(fill="both", expand=True)

        R = 0
        def row(label, widget_factory, **kw):
            nonlocal R
            ttk.Label(lf, text=label).grid(row=R, column=0, sticky="w", padx=8, pady=6)
            w = widget_factory(lf, **kw); w.grid(row=R, column=1, sticky="ew", padx=8, pady=6)
            R += 1; return w

        self.v_role_name   = tk.StringVar()
        self.v_ref_audio   = tk.StringVar()
        self.v_prompt_text = tk.StringVar()
        self.v_prompt_lang = tk.StringVar()
        self.v_text_lang   = tk.StringVar()
        self.v_cut_method  = tk.StringVar()
        self.v_speed       = tk.DoubleVar(value=1.0)

        row("角色名称：",   ttk.Entry, textvariable=self.v_role_name, width=36)
        # ref_audio 行（带浏览按钮）
        ttk.Label(lf, text="参考音频路径：").grid(row=R, column=0, sticky="w", padx=8, pady=6)
        rf = ttk.Frame(lf); rf.grid(row=R, column=1, sticky="ew", padx=8, pady=6)
        ttk.Entry(rf, textvariable=self.v_ref_audio, width=38).pack(side="left", fill="x", expand=True)
        ttk.Button(rf, text="…", width=3, command=lambda: self._browse_file(self.v_ref_audio)
                   ).pack(side="left", padx=(4,0)); R += 1

        row("参考音频台词：", ttk.Entry, textvariable=self.v_prompt_text, width=36)

        # 语言下拉（prompt_lang）
        ttk.Label(lf, text="参考音频语言：").grid(row=R, column=0, sticky="w", padx=8, pady=6)
        cb_pl = ttk.Combobox(lf, textvariable=self.v_prompt_lang, state="readonly", width=18)
        cb_pl["values"] = [f"{d}  [{c}]" for d, c in LANG_OPTIONS]
        cb_pl.grid(row=R, column=1, sticky="w", padx=8, pady=6); R += 1

        # 语言下拉（text_lang）
        ttk.Label(lf, text="合成文本语言：").grid(row=R, column=0, sticky="w", padx=8, pady=6)
        cb_tl = ttk.Combobox(lf, textvariable=self.v_text_lang, state="readonly", width=18)
        cb_tl["values"] = [f"{d}  [{c}]" for d, c in LANG_OPTIONS]
        cb_tl.grid(row=R, column=1, sticky="w", padx=8, pady=6); R += 1

        # cut 方法
        ttk.Label(lf, text="分割方法：").grid(row=R, column=0, sticky="w", padx=8, pady=6)
        cb_cut = ttk.Combobox(lf, textvariable=self.v_cut_method, state="readonly", width=28)
        cb_cut["values"] = [f"{d}" for d, c in CUT_OPTIONS]
        cb_cut.grid(row=R, column=1, sticky="w", padx=8, pady=6); R += 1

        # 语速滑块
        ttk.Label(lf, text="语速：").grid(row=R, column=0, sticky="w", padx=8, pady=6)
        spd_frame = ttk.Frame(lf); spd_frame.grid(row=R, column=1, sticky="ew", padx=8, pady=6)
        self.speed_label = ttk.Label(spd_frame, text="1.00", width=5)
        sc = ttk.Scale(spd_frame, from_=0.5, to=2.0, variable=self.v_speed, orient="horizontal",
                       command=lambda v: self.speed_label.config(text=f"{float(v):.2f}"))
        sc.pack(side="left", fill="x", expand=True)
        self.speed_label.pack(side="left", padx=6); R += 1

        lf.columnconfigure(1, weight=1)

        btn_row = ttk.Frame(lf); btn_row.grid(row=R, column=0, columnspan=2, pady=12)
        ttk.Button(btn_row, text="💾 保存角色", style="Accent.TButton",
                   command=self._role_save).pack(side="left", padx=6)
        ttk.Button(btn_row, text="🔄 重置", command=self._role_reset).pack(side="left", padx=6)

    def _lang_display(self, code):
        for d, c in LANG_OPTIONS:
            if c == code: return f"{d}  [{c}]"
        return f"自动  [auto]"

    def _lang_code(self, display):
        for d, c in LANG_OPTIONS:
            if f"{d}  [{c}]" == display: return c
        return "auto"

    def _cut_display(self, code):
        for d, c in CUT_OPTIONS:
            if c == code: return d
        return CUT_OPTIONS[-1][0]

    def _cut_code(self, display):
        for d, c in CUT_OPTIONS:
            if d == display: return c
        return "cut5"

    def _refresh_role_list(self, select_name=None):
        self.role_listbox.delete(0, "end")
        for name in self.cfg["roles"]:
            self.role_listbox.insert("end", name)
        if select_name:
            names = list(self.cfg["roles"].keys())
            if select_name in names:
                idx = names.index(select_name)
                self.role_listbox.selection_set(idx)
                self.role_listbox.see(idx)
                self._load_role(select_name)
        elif self.role_listbox.size() > 0:
            self.role_listbox.selection_set(0)
            self._load_role(list(self.cfg["roles"].keys())[0])

    def _on_role_select(self, _=None):
        sel = self.role_listbox.curselection()
        if not sel: return
        name = self.role_listbox.get(sel[0])
        self._load_role(name)

    def _load_role(self, name):
        r = self.cfg["roles"].get(name, {})
        self.v_role_name.set(name)
        self.v_ref_audio.set(r.get("ref_audio_path", ""))
        self.v_prompt_text.set(r.get("prompt_text", ""))
        self.v_prompt_lang.set(self._lang_display(r.get("prompt_lang", "zh")))
        self.v_text_lang.set(self._lang_display(r.get("text_lang", "zh")))
        self.v_cut_method.set(self._cut_display(r.get("text_split_method", "cut5")))
        spd = r.get("speed_factor", 1.0)
        self.v_speed.set(spd)
        self.speed_label.config(text=f"{spd:.2f}")
        self._editing_role = name

    def _role_save(self):
        old_name = getattr(self, "_editing_role", None)
        new_name = self.v_role_name.get().strip()
        if not new_name:
            messagebox.showwarning("提示", "角色名称不能为空"); return
        entry = {
            "ref_audio_path":   self.v_ref_audio.get().strip(),
            "prompt_text":      self.v_prompt_text.get().strip(),
            "prompt_lang":      self._lang_code(self.v_prompt_lang.get()),
            "text_lang":        self._lang_code(self.v_text_lang.get()),
            "text_split_method": self._cut_code(self.v_cut_method.get()),
            "speed_factor":     round(self.v_speed.get(), 2),
        }
        if old_name and old_name != new_name and old_name in self.cfg["roles"]:
            del self.cfg["roles"][old_name]
        self.cfg["roles"][new_name] = entry
        self._editing_role = new_name
        self._refresh_role_list(select_name=new_name)
        self._log_msg(f"[角色] '{new_name}' 已保存")

    def _role_reset(self):
        name = getattr(self, "_editing_role", None)
        if name: self._load_role(name)

    def _role_add(self):
        name = f"新角色{len(self.cfg['roles'])+1}"
        self.cfg["roles"][name] = {
            "ref_audio_path": "", "prompt_text": "",
            "prompt_lang": "zh", "text_lang": "zh",
            "text_split_method": "cut5", "speed_factor": 1.0
        }
        self._refresh_role_list(select_name=name)

    def _role_delete(self):
        sel = self.role_listbox.curselection()
        if not sel: return
        name = self.role_listbox.get(sel[0])
        if messagebox.askyesno("确认", f"删除角色「{name}」？"):
            del self.cfg["roles"][name]
            self._refresh_role_list()

    # ════════════════════════════════════════════════
    #  标签页：服务器管理
    # ════════════════════════════════════════════════
    def _build_servers_tab(self):
        f = self.tab_servers

        # ── 顶部工具栏 ──
        top_bar = ttk.Frame(f); top_bar.pack(fill="x", padx=12, pady=(10,4))
        ttk.Button(top_bar, text="＋ 添加机器组", style="Success.TButton",
                   command=self._server_add_group).pack(side="left", padx=4)
        ttk.Button(top_bar, text="🔍 检测所有", style="Accent.TButton",
                   command=self._server_check_all).pack(side="left", padx=4)
        ttk.Button(top_bar, text="✕ 删除选中", style="Danger.TButton",
                   command=self._server_delete).pack(side="left", padx=4)
        ttk.Button(top_bar, text="⬆ 上移", command=self._server_move_up).pack(side="left", padx=4)
        ttk.Button(top_bar, text="⬇ 下移", command=self._server_move_down).pack(side="left", padx=4)

        # ── 快速开关栏 ──
        sw_bar = ttk.Frame(f); sw_bar.pack(fill="x", padx=12, pady=(0,4))
        ttk.Label(sw_bar, text="快速开关：", foreground=self.colors["ACC"]).pack(side="left", padx=(0,6))
        ttk.Button(sw_bar, text="✅ 全部启用",  style="Success.TButton",
                   command=lambda: self._server_toggle_all(True)).pack(side="left", padx=3)
        ttk.Button(sw_bar, text="⛔ 全部禁用",  style="Danger.TButton",
                   command=lambda: self._server_toggle_all(False)).pack(side="left", padx=3)
        ttk.Button(sw_bar, text="🎯 只启用选中",
                   command=self._server_toggle_only_selected).pack(side="left", padx=3)
        ttk.Button(sw_bar, text="🔄 切换选中状态",
                   command=self._server_toggle_selected).pack(side="left", padx=3)

        # ── 树形列表 ──
        tree_frame = ttk.Frame(f); tree_frame.pack(fill="both", expand=True, padx=12, pady=(0,4))
        sb = ttk.Scrollbar(tree_frame); sb.pack(side="right", fill="y")
        self.srv_tree = ttk.Treeview(tree_frame, yscrollcommand=sb.set,
                                      columns=("url", "enabled", "status"), show="tree headings")
        self.srv_tree.heading("#0",       text="名称/IP",   anchor="w")
        self.srv_tree.heading("url",      text="地址",      anchor="w")
        self.srv_tree.heading("enabled",  text="启用",      anchor="center")
        self.srv_tree.heading("status",   text="状态",      anchor="w")
        self.srv_tree.column("#0",        width=160, stretch=False)
        self.srv_tree.column("url",       width=280)
        self.srv_tree.column("enabled",   width=70,  stretch=False, anchor="center")
        self.srv_tree.column("status",    width=160, stretch=False)
        self.srv_tree.pack(fill="both", expand=True)
        sb.config(command=self.srv_tree.yview)
        self.srv_tree.bind("<Double-1>", self._server_edit)
        self.srv_tree.bind("<space>",    lambda e: self._server_toggle_selected())

        # 颜色标签
        self.srv_tree.tag_configure("enabled",  foreground=self.colors["GRN"])
        self.srv_tree.tag_configure("disabled", foreground="#6c7086")
        self.srv_tree.tag_configure("group_on", foreground=self.colors["ACC"],
                                    font=("Microsoft YaHei UI", 10, "bold"))
        self.srv_tree.tag_configure("group_off",foreground="#6c7086",
                                    font=("Microsoft YaHei UI", 10))

        # ── 编辑栏 ──
        edit_lf = ttk.LabelFrame(f, text="编辑选中项", padding=10)
        edit_lf.pack(fill="x", padx=12, pady=(0,8))
        ttk.Label(edit_lf, text="名称：").grid(row=0, column=0, padx=6, pady=4, sticky="w")
        self.v_srv_name = tk.StringVar()
        ttk.Entry(edit_lf, textvariable=self.v_srv_name, width=22).grid(row=0, column=1, padx=6, pady=4)
        ttk.Label(edit_lf, text="地址（完整URL）：").grid(row=0, column=2, padx=6, pady=4, sticky="w")
        self.v_srv_url = tk.StringVar()
        ttk.Entry(edit_lf, textvariable=self.v_srv_url, width=36).grid(row=0, column=3, padx=6, pady=4, sticky="ew")
        ttk.Button(edit_lf, text="应用修改", style="Accent.TButton",
                   command=self._server_apply_edit).grid(row=0, column=4, padx=8, pady=4)
        ttk.Button(edit_lf, text="＋ 添加IP到组",
                   command=self._server_add_ip).grid(row=0, column=5, padx=4, pady=4)
        edit_lf.columnconfigure(3, weight=1)

        self._refresh_server_tree()

    def _srv_enabled_icon(self, enabled):
        return "✅" if enabled else "⛔"

    def _refresh_server_tree(self):
        self.srv_tree.delete(*self.srv_tree.get_children())
        for gi, grp in enumerate(self.cfg["server_groups"]):
            grp_en = grp.get("enabled", True)
            grp_icon = self._srv_enabled_icon(grp_en)
            grp_tag = "group_on" if grp_en else "group_off"
            gid = self.srv_tree.insert("", "end", iid=f"g{gi}",
                                        text=f"{grp_icon}  {grp['name']}",
                                        values=("", grp_icon, ""),
                                        tags=(grp_tag,),
                                        open=True)
            for ui, uobj in enumerate(grp["urls"]):
                url = uobj["url"] if isinstance(uobj, dict) else uobj
                en  = uobj.get("enabled", True) if isinstance(uobj, dict) else True
                en_icon = self._srv_enabled_icon(en)
                tag = "enabled" if (en and grp_en) else "disabled"
                self.srv_tree.insert(gid, "end", iid=f"g{gi}u{ui}",
                                      text=f"    {url.split('/')[2]}",
                                      values=(url, en_icon, "—"),
                                      tags=(tag,))

    # ── 开关操作 ──
    def _get_sel_gi_ui(self):
        """返回 (gi, ui)，ui=None 表示选中的是机器组"""
        sel = self.srv_tree.focus()
        if not sel: return None, None
        if "u" not in sel:
            return int(sel[1:]), None
        gi = int(sel[1:sel.index("u")])
        ui = int(sel[sel.index("u")+1:])
        return gi, ui

    def _server_toggle_selected(self):
        """切换选中行的启用状态"""
        gi, ui = self._get_sel_gi_ui()
        if gi is None: return
        if ui is None:
            grp = self.cfg["server_groups"][gi]
            grp["enabled"] = not grp.get("enabled", True)
        else:
            uobj = self.cfg["server_groups"][gi]["urls"][ui]
            uobj["enabled"] = not uobj.get("enabled", True)
        self._refresh_server_tree()
        self._sync_proxy_backends()

    def _server_toggle_all(self, state: bool):
        """全部启用/禁用"""
        for grp in self.cfg["server_groups"]:
            grp["enabled"] = state
            for uobj in grp["urls"]:
                uobj["enabled"] = state
        self._refresh_server_tree()
        self._sync_proxy_backends()

    def _server_toggle_only_selected(self):
        """只启用选中的IP/组，其余全部禁用"""
        sel = self.srv_tree.focus()
        if not sel: return
        # 先全禁
        for grp in self.cfg["server_groups"]:
            grp["enabled"] = False
            for uobj in grp["urls"]: uobj["enabled"] = False
        # 再开选中
        if "u" not in sel:
            gi = int(sel[1:])
            grp = self.cfg["server_groups"][gi]
            grp["enabled"] = True
            for uobj in grp["urls"]: uobj["enabled"] = True
        else:
            gi = int(sel[1:sel.index("u")])
            ui = int(sel[sel.index("u")+1:])
            self.cfg["server_groups"][gi]["enabled"] = True
            self.cfg["server_groups"][gi]["urls"][ui]["enabled"] = True
        self._refresh_server_tree()
        self._sync_proxy_backends()

    def _sync_proxy_backends(self):
        """服务器启用状态变更后，立即同步保存并热重载代理后端（无感知）"""
        save_config(self.cfg)
        if self._proxy and self._proxy.running:
            self._proxy.reload_backends()
            # 刷新代理标签页的后端列表显示
            try:
                self._proxy_refresh_backends()
            except Exception:
                pass

    # ── CRUD ──
    def _server_add_group(self):
        name = f"新机器组{len(self.cfg['server_groups'])+1}"
        self.cfg["server_groups"].append({"name": name, "enabled": True, "urls": []})
        self._refresh_server_tree()

    def _server_add_ip(self):
        sel = self.srv_tree.focus()
        if not sel: messagebox.showinfo("提示", "请先选中一个机器组"); return
        if "u" not in sel: gi = int(sel[1:])
        else: gi = int(sel[1:sel.index("u")])
        url = self.v_srv_url.get().strip()
        if not url: messagebox.showwarning("提示", "请在编辑栏填写URL"); return
        self.cfg["server_groups"][gi]["urls"].append({"url": url, "enabled": True})
        self._refresh_server_tree()
        self.v_srv_url.set("")

    def _server_delete(self):
        gi, ui = self._get_sel_gi_ui()
        if gi is None: return
        if ui is None:
            name = self.cfg["server_groups"][gi]["name"]
            if messagebox.askyesno("确认", f"删除机器组「{name}」及其所有IP？"):
                del self.cfg["server_groups"][gi]
                self._refresh_server_tree()
        else:
            if messagebox.askyesno("确认", "删除此IP？"):
                del self.cfg["server_groups"][gi]["urls"][ui]
                self._refresh_server_tree()

    def _server_move_up(self):
        gi, ui = self._get_sel_gi_ui()
        if gi is None or ui is not None: return
        if gi == 0: return
        g = self.cfg["server_groups"]
        g[gi-1], g[gi] = g[gi], g[gi-1]
        self._refresh_server_tree()

    def _server_move_down(self):
        gi, ui = self._get_sel_gi_ui()
        if gi is None or ui is not None: return
        g = self.cfg["server_groups"]
        if gi >= len(g)-1: return
        g[gi], g[gi+1] = g[gi+1], g[gi]
        self._refresh_server_tree()

    def _server_edit(self, _=None):
        gi, ui = self._get_sel_gi_ui()
        if gi is None: return
        if ui is None:
            self.v_srv_name.set(self.cfg["server_groups"][gi]["name"])
            self.v_srv_url.set("")
        else:
            uobj = self.cfg["server_groups"][gi]["urls"][ui]
            self.v_srv_name.set(f"IP {ui+1}")
            self.v_srv_url.set(uobj["url"] if isinstance(uobj, dict) else uobj)

    def _server_apply_edit(self):
        gi, ui = self._get_sel_gi_ui()
        if gi is None: return
        if ui is None:
            self.cfg["server_groups"][gi]["name"] = self.v_srv_name.get().strip()
        else:
            url = self.v_srv_url.get().strip()
            if url:
                uobj = self.cfg["server_groups"][gi]["urls"][ui]
                if isinstance(uobj, dict): uobj["url"] = url
                else: self.cfg["server_groups"][gi]["urls"][ui] = {"url": url, "enabled": True}
        self._refresh_server_tree()

    def _server_check_all(self):
        self._log_msg("[服务器检测] 开始检测所有IP...")
        def _check():
            for gi, grp in enumerate(self.cfg["server_groups"]):
                for ui, uobj in enumerate(grp["urls"]):
                    url = uobj["url"] if isinstance(uobj, dict) else uobj
                    en  = uobj.get("enabled", True) if isinstance(uobj, dict) else True
                    ok, msg = check_server(url)
                    icon = "✅" if ok else "❌"
                    dis  = " [已禁用]" if not en else ""
                    iid  = f"g{gi}u{ui}"
                    self.after(0, lambda i=iid, m=msg+dis: self.srv_tree.set(i, "status", m))
                    self._log_msg(f"  {icon} {url}{dis}  → {msg}")
            self._log_msg("[服务器检测] 完成")
        threading.Thread(target=_check, daemon=True).start()

    # ════════════════════════════════════════════════
    #  标签页：代理服务
    # ════════════════════════════════════════════════
    def _build_proxy_tab(self):
        f = self.tab_proxy
        proxy_cfg = self.cfg.get("proxy", {})

        # ── 配置区 ──
        cfg_lf = ttk.LabelFrame(f, text="代理服务配置", padding=16)
        cfg_lf.pack(fill="x", padx=16, pady=(14,6))

        # ── 互联通讯端口 ──
        ttk.Label(cfg_lf, text="互联通讯端口：").grid(row=0, column=0, sticky="w", padx=8, pady=7)
        self.v_proxy_port = tk.IntVar(value=proxy_cfg.get("port", 9882))
        port_frame = ttk.Frame(cfg_lf); port_frame.grid(row=0, column=1, sticky="w", padx=8)
        ttk.Spinbox(port_frame, from_=1024, to=65535, textvariable=self.v_proxy_port,
                    width=8, font=("Microsoft YaHei UI", 11)).pack(side="left")
        ttk.Label(port_frame, text="  加速器之间互联用（对方填 http://本机IP:此端口/tts）",
                  foreground="#6c7086").pack(side="left")

        # ── 本机 TTS 监听端口（可选，与互联端口分离）──
        ttk.Label(cfg_lf, text="本机TTS监听端口：").grid(row=1, column=0, sticky="w", padx=8, pady=7)
        tts_port_frame = ttk.Frame(cfg_lf); tts_port_frame.grid(row=1, column=1, sticky="w", padx=8)
        self.v_tts_port_enabled = tk.BooleanVar(value=proxy_cfg.get("tts_port_enabled", False))
        ttk.Checkbutton(tts_port_frame, variable=self.v_tts_port_enabled,
                        text="同时开启  ").pack(side="left")
        self.v_tts_port = tk.IntVar(value=proxy_cfg.get("tts_port", 9880))
        ttk.Spinbox(tts_port_frame, from_=1024, to=65535, textvariable=self.v_tts_port,
                    width=8, font=("Microsoft YaHei UI", 11)).pack(side="left")
        ttk.Label(tts_port_frame,
                  text="  tts_reply.py / 本地应用 填这个端口（不影响互联端口）",
                  foreground="#6c7086").pack(side="left")

        # 自动启动
        ttk.Label(cfg_lf, text="随配置器自动启动：").grid(row=2, column=0, sticky="w", padx=8, pady=7)
        self.v_proxy_auto = tk.BooleanVar(value=proxy_cfg.get("auto_start", False))
        ttk.Checkbutton(cfg_lf, variable=self.v_proxy_auto).grid(row=2, column=1, sticky="w", padx=8)

        # 调试模式
        ttk.Label(cfg_lf, text="调试模式：").grid(row=3, column=0, sticky="w", padx=8, pady=7)
        debug_frame = ttk.Frame(cfg_lf); debug_frame.grid(row=3, column=1, sticky="w", padx=8)
        self.v_proxy_debug = tk.BooleanVar(value=proxy_cfg.get("debug_mode", False))
        ttk.Checkbutton(debug_frame, variable=self.v_proxy_debug,
                        text="开启  ", command=self._on_debug_toggle).pack(side="left")
        debug_log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tts_proxy_debug.log")
        ttk.Label(debug_frame,
                  text=f"记录完整请求 → {debug_log_path}",
                  foreground="#6c7086").pack(side="left")

        # 本机IP显示
        ttk.Label(cfg_lf, text="本机地址：").grid(row=4, column=0, sticky="w", padx=8, pady=7)
        self.v_proxy_addr = tk.StringVar(value=self._get_local_ips())
        ttk.Label(cfg_lf, textvariable=self.v_proxy_addr,
                  foreground=self.colors["ACC"]).grid(row=4, column=1, sticky="w", padx=8)

        cfg_lf.columnconfigure(1, weight=1)

        # ── 控制按钮 ──
        ctrl = ttk.Frame(f); ctrl.pack(fill="x", padx=16, pady=6)

        self.btn_proxy_start = ttk.Button(ctrl, text="▶  启动代理", style="Success.TButton",
                                           command=self._proxy_start)
        self.btn_proxy_start.pack(side="left", padx=4)

        self.btn_proxy_stop = ttk.Button(ctrl, text="⏹  停止代理", style="Danger.TButton",
                                          command=self._proxy_stop, state="disabled")
        self.btn_proxy_stop.pack(side="left", padx=4)

        ttk.Button(ctrl, text="🔄 重载后端", command=self._proxy_reload,
                   ).pack(side="left", padx=4)

        ttk.Button(ctrl, text="📋 复制接口地址", command=self._proxy_copy_url,
                   ).pack(side="left", padx=4)

        ttk.Button(ctrl, text="🗑 清空日志", command=self._proxy_log_clear
                   ).pack(side="right", padx=4)

        # ── 状态栏 ──
        stat_frame = ttk.LabelFrame(f, text="运行状态", padding=10)
        stat_frame.pack(fill="x", padx=16, pady=(0,4))

        self.v_proxy_status = tk.StringVar(value="⏹  未运行")
        ttk.Label(stat_frame, textvariable=self.v_proxy_status,
                  font=("Microsoft YaHei UI", 11, "bold"),
                  foreground=self.colors["YEL"]).grid(row=0, column=0, padx=8, sticky="w")

        ttk.Label(stat_frame, text="总请求：").grid(row=0, column=1, padx=(20,4), sticky="w")
        self.v_proxy_req  = tk.StringVar(value="0")
        ttk.Label(stat_frame, textvariable=self.v_proxy_req,
                  foreground=self.colors["ACC"]).grid(row=0, column=2, sticky="w")

        ttk.Label(stat_frame, text="成功：").grid(row=0, column=3, padx=(16,4), sticky="w")
        self.v_proxy_ok   = tk.StringVar(value="0")
        ttk.Label(stat_frame, textvariable=self.v_proxy_ok,
                  foreground=self.colors["GRN"]).grid(row=0, column=4, sticky="w")

        ttk.Label(stat_frame, text="失败：").grid(row=0, column=5, padx=(16,4), sticky="w")
        self.v_proxy_fail = tk.StringVar(value="0")
        ttk.Label(stat_frame, textvariable=self.v_proxy_fail,
                  foreground=self.colors["RED"]).grid(row=0, column=6, sticky="w")

        ttk.Label(stat_frame, text="后端数量：").grid(row=0, column=7, padx=(16,4), sticky="w")
        self.v_proxy_backends = tk.StringVar(value="0")
        ttk.Label(stat_frame, textvariable=self.v_proxy_backends,
                  foreground=self.colors["FG"]).grid(row=0, column=8, sticky="w")

        # ── 日志区 ──
        log_lf = ttk.LabelFrame(f, text="代理日志", padding=8)
        log_lf.pack(fill="both", expand=True, padx=16, pady=(0,12))

        self.proxy_log_box = scrolledtext.ScrolledText(
            log_lf,
            bg=self.colors["SEL"], fg=self.colors["FG"],
            insertbackground=self.colors["FG"],
            font=("Consolas", 10),
            state="disabled", wrap="word"
        )
        self.proxy_log_box.pack(fill="both", expand=True)

        # 颜色 tag
        self.proxy_log_box.tag_config("ok",    foreground=self.colors["GRN"])
        self.proxy_log_box.tag_config("err",   foreground=self.colors["RED"])
        self.proxy_log_box.tag_config("warn",  foreground=self.colors["YEL"])
        self.proxy_log_box.tag_config("info",  foreground=self.colors["ACC"])

    # ── 代理操作 ──────────────────────────────────────────

    def _get_local_ips(self):
        """获取本机所有非回环 IP"""
        ips = []
        try:
            hostname = socket.gethostname()
            infos = socket.getaddrinfo(hostname, None)
            for info in infos:
                ip = info[4][0]
                if not ip.startswith("127.") and ":" not in ip:
                    if ip not in ips:
                        ips.append(ip)
        except Exception:
            pass
        if not ips:
            ips = ["127.0.0.1"]
        port = self.v_proxy_port.get() if hasattr(self, "v_proxy_port") else 9882
        return "  |  ".join(f"http://{ip}:{port}/tts" for ip in ips[:3])

    def _proxy_log(self, msg: str):
        """线程安全地向代理日志框追加一行"""
        def _do():
            self.proxy_log_box.config(state="normal")
            # 根据关键词选颜色
            if "[OK]" in msg or "成功" in msg or "启动" in msg:
                tag = "ok"
            elif "[错误]" in msg or "失败" in msg or "离线" in msg:
                tag = "err"
            elif "[警告]" in msg or "警告" in msg:
                tag = "warn"
            else:
                tag = "info"
            self.proxy_log_box.insert("end", msg + "\n", tag)
            self.proxy_log_box.see("end")
            self.proxy_log_box.config(state="disabled")
        self.after(0, _do)

    def _proxy_stats(self, req, ok, fail):
        """更新统计数字（从任意线程调用）"""
        def _do():
            self.v_proxy_req.set(str(req))
            self.v_proxy_ok.set(str(ok))
            self.v_proxy_fail.set(str(fail))
        self.after(0, _do)

    def _on_debug_toggle(self):
        """调试模式勾选框回调"""
        import tts_proxy as _tp
        enabled = self.v_proxy_debug.get()
        _tp.set_debug_mode(enabled)

    def _proxy_start(self):
        if self._proxy and self._proxy.running:
            return
        # 先保存配置，确保 proxy 用最新后端
        self._collect_global()
        save_config(self.cfg)

        port = self.v_proxy_port.get()
        tts_port_enabled = self.v_tts_port_enabled.get()
        tts_port = self.v_tts_port.get() if tts_port_enabled else None

        # 同步调试模式状态
        import tts_proxy as _tp
        _tp.set_debug_mode(self.v_proxy_debug.get())

        # ── 强制清理端口残留进程 ──────────────────────────────
        self._kill_port(port)
        if tts_port and tts_port != port:
            self._kill_port(tts_port)

        from tts_proxy import TTSProxyServer
        try:
            self._proxy = TTSProxyServer(
                port=port,
                tts_port=tts_port,
                config_path=CONFIG_PATH,
                log_cb=self._proxy_log,
                stats_cb=self._proxy_stats,
            )
            self._proxy.start()
        except OSError as e:
            self._proxy_log(f"[错误] 启动失败: {e}")
            return

        # 更新后端数量
        backend_count = len(self._proxy._server.RequestHandlerClass.__module__ and
                            __import__("tts_proxy")._state.backends)
        self.after(0, lambda: self.v_proxy_backends.set(
            str(len(__import__("tts_proxy")._state.backends))))

        status_txt = f"▶  运行中  互联:{port}"
        if tts_port:
            status_txt += f"  TTS:{tts_port}"
        self.after(0, lambda: self.v_proxy_status.set(status_txt))
        self.after(0, lambda: self.v_proxy_addr.set(self._get_local_ips()))
        self.after(0, lambda: self.btn_proxy_start.config(state="disabled"))
        self.after(0, lambda: self.btn_proxy_stop.config(state="normal"))

        # 定时刷新后端数量
        self._proxy_refresh_backends()

    def _kill_port(self, port: int):
        """强制杀掉占用指定端口的所有进程（启动代理前清场）"""
        import subprocess, sys as _sys
        try:
            r = subprocess.run(
                f'netstat -ano | findstr ":{port} "',
                shell=True, capture_output=True, text=True
            )
            pids = set()
            for line in r.stdout.splitlines():
                parts = line.strip().split()
                if parts:
                    try:
                        pids.add(int(parts[-1]))
                    except Exception:
                        pass
            own_pid = os.getpid()
            for pid in pids:
                if pid <= 4 or pid == own_pid:
                    continue
                subprocess.run(f'taskkill /f /pid {pid}',
                               shell=True, capture_output=True)
                self._proxy_log(f"[清理] 已终止旧代理进程 PID {pid}")
            if pids - {own_pid}:
                import time as _t; _t.sleep(0.5)
        except Exception as e:
            self._proxy_log(f"[清理] 端口清理时出错（可忽略）: {e}")

    def _proxy_stop(self):
        if self._proxy:
            self._proxy.stop()
            self._proxy = None
        self.after(0, lambda: self.v_proxy_status.set("⏹  未运行"))
        self.after(0, lambda: self.btn_proxy_start.config(state="normal"))
        self.after(0, lambda: self.btn_proxy_stop.config(state="disabled"))

    def _proxy_reload(self):
        """重新加载后端列表（不重启服务）"""
        if self._proxy and self._proxy.running:
            self._collect_global()
            save_config(self.cfg)
            self._proxy.reload_backends()
            self._proxy_refresh_backends()
            self._proxy_log("[重载] 后端列表已更新")
        else:
            self._proxy_log("[提示] 代理服务未运行，请先启动")

    def _proxy_refresh_backends(self):
        """更新 GUI 上的后端数量显示"""
        try:
            import tts_proxy as _tp
            self.after(0, lambda: self.v_proxy_backends.set(str(len(_tp._state.backends))))
        except Exception:
            pass

    def _proxy_copy_url(self):
        port = self.v_proxy_port.get()
        url = f"http://127.0.0.1:{port}/tts"
        self.clipboard_clear()
        self.clipboard_append(url)
        self._proxy_log(f"[复制] {url}")

    def _proxy_log_clear(self):
        self.proxy_log_box.config(state="normal")
        self.proxy_log_box.delete("1.0", "end")
        self.proxy_log_box.config(state="disabled")

    # ════════════════════════════════════════════════
    #  标签页：测试播放
    # ════════════════════════════════════════════════
    def _build_test_tab(self):
        f = self.tab_test

        top = ttk.LabelFrame(f, text="测试参数", padding=14)
        top.pack(fill="x", padx=12, pady=(12,6))

        ttk.Label(top, text="角色：").grid(row=0, column=0, padx=6, pady=6, sticky="w")
        self.v_test_role = tk.StringVar()
        self.cb_test_role = ttk.Combobox(top, textvariable=self.v_test_role, state="readonly", width=14)
        self.cb_test_role.grid(row=0, column=1, padx=6, pady=6, sticky="w")
        self.nb.bind("<<NotebookTabChanged>>", self._on_tab_change)

        ttk.Label(top, text="测试台词：").grid(row=0, column=2, padx=6, pady=6, sticky="w")
        self.v_test_text = tk.StringVar(
            value="旅行者，今天天气真好！可莉想去原野抓松鼠。蹦蹦炸弹也要带上！万一遇到丘丘人，就用炸弹轰他们！炸完之后我们再去采蘑菇，可莉最喜欢吃蘑菇汤了！")
        ttk.Entry(top, textvariable=self.v_test_text, width=54).grid(row=0, column=3, padx=6, pady=6, sticky="ew")
        top.columnconfigure(3, weight=1)

        btn_row = ttk.Frame(f); btn_row.pack(fill="x", padx=12, pady=4)
        self.btn_play = ttk.Button(btn_row, text="▶  生成并播放", style="Accent.TButton",
                                    command=self._test_play)
        self.btn_play.pack(side="left", padx=4)
        ttk.Button(btn_row, text="⏹  停止", style="Danger.TButton",
                   command=self._test_stop).pack(side="left", padx=4)
        ttk.Button(btn_row, text="🗑  清空日志", command=self._log_clear).pack(side="right", padx=4)

        # 进度条
        self.progress_var = tk.DoubleVar(value=0)
        pb = ttk.Progressbar(f, variable=self.progress_var, maximum=100)
        pb.pack(fill="x", padx=12, pady=(2,4))

        # 日志
        log_lf = ttk.LabelFrame(f, text="运行日志", padding=8)
        log_lf.pack(fill="both", expand=True, padx=12, pady=(0,10))
        self.log_box = scrolledtext.ScrolledText(log_lf, bg=self.colors["SEL"],
                                                  fg=self.colors["FG"],
                                                  insertbackground=self.colors["FG"],
                                                  font=("Consolas", 10),
                                                  state="disabled", wrap="word")
        self.log_box.pack(fill="both", expand=True)

        self._test_thread = None
        self._test_stop_flag = False

    def _on_tab_change(self, _=None):
        names = list(self.cfg["roles"].keys())
        self.cb_test_role["values"] = names
        if names and not self.v_test_role.get():
            self.v_test_role.set(names[0])

    def _test_play(self):
        if self._test_thread and self._test_thread.is_alive(): return
        role_name = self.v_test_role.get()
        text = self.v_test_text.get().strip()
        if not role_name or not text:
            messagebox.showwarning("提示", "请选择角色并填写测试台词"); return
        self._test_stop_flag = False
        self.btn_play.config(state="disabled")
        self.progress_var.set(0)
        self._test_thread = threading.Thread(target=self._test_worker,
                                              args=(role_name, text), daemon=True)
        self._test_thread.start()

    def _test_stop(self):
        self._test_stop_flag = True
        self._log_msg("[停止] 已发出停止信号，当前句合成完后中断")

    def _test_worker(self, role_name, text):
        cfg = self.cfg
        role_cfg = cfg["roles"].get(role_name)
        if not role_cfg:
            self._log_msg(f"[错误] 角色 '{role_name}' 不存在"); self._test_done(); return

        mode = cfg.get("mode", "direct")

        self._log_msg(f"\n{'='*52}")
        self._log_msg(f"[{role_name}] 模式={mode}  {text}")
        self._log_msg(f"{'='*52}")

        t_start = datetime.now()
        wav_data = None

        # ── 代理模式（proxy_server / proxy_client）────────────
        if mode in ("proxy_server", "proxy_client"):
            if mode == "proxy_server":
                proxy_port = cfg.get("proxy", {}).get("port", 9882)
                proxy_url = f"http://127.0.0.1:{proxy_port}/tts"
            else:
                proxy_url = cfg.get("client", {}).get("proxy_url", "http://192.168.28.3:9882/tts")

            self._log_msg(f"[代理] → {proxy_url}")
            self._log_msg(f"[说明] 代理负责拆句并发，本机发完整文本等待合并结果")

            payload = build_payload(role_cfg, text)
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            try:
                req = urllib.request.Request(
                    proxy_url, data=data,
                    headers={"Content-Type": "application/json"}
                )
                r = urllib.request.urlopen(req, timeout=180)
                audio = r.read()
                backend_info = r.headers.get("X-Backend", "")
                elapsed_proxy = r.headers.get("X-Elapsed", "")
                if len(audio) > 100:
                    wav_data = audio
                    self._log_msg(f"  [OK] {len(audio):,} bytes")
                    if backend_info:
                        self._log_msg(f"  [后端] {backend_info[:100]}")
                    self.after(0, lambda: self.progress_var.set(100))
                else:
                    self._log_msg(f"  [!] 代理返回数据过小 ({len(audio)} bytes)")
            except urllib.error.HTTPError as e:
                self._log_msg(f"  [!] 代理返回 HTTP {e.code}: {e.read(200).decode(errors='replace')[:100]}")
            except Exception as e:
                self._log_msg(f"  [!] 代理连接失败 {type(e).__name__}: {e}")

        # ── 直连模式（direct）────────────────────────────────
        else:
            sentences = split_sentences(text)
            total = len(sentences)
            threshold = cfg.get("parallel_threshold", 2)
            self._log_msg(f"[分句] 共 {total} 句，并行阈值={threshold}")
            self._log_msg(f"[模式] {'流水线并行' if total >= threshold else '串行'}")
            self._log_msg(f"  → {sentences}")

            server_groups = [
                [u["url"] if isinstance(u, dict) else u
                 for u in grp["urls"]
                 if (u.get("enabled", True) if isinstance(u, dict) else True)]
                for grp in cfg["server_groups"]
                if grp.get("enabled", True)
            ]
            server_groups = [g for g in server_groups if g]
            if not server_groups:
                self._log_msg("[错误] 没有配置服务器"); self._test_done(); return

            if total < threshold:
                all_urls = [u for g in server_groups for u in g]
                wav_list = []
                for i, s in enumerate(sentences):
                    if self._test_stop_flag: break
                    payload = build_payload(role_cfg, s)
                    audio, used = request_tts(all_urls, payload)
                    self.after(0, lambda p=(i+1)/total*100: self.progress_var.set(p))
                    if audio:
                        wav_list.append(audio)
                        host = used.split("/")[2] if used else "?"
                        self._log_msg(f"  [OK] 句{i+1}/{total} ({len(audio):,} bytes) ← {host}")
                    else:
                        self._log_msg(f"  [--] 句{i+1}/{total} 失败，跳过")
                wav_data = merge_wav_bytes(wav_list) if wav_list else None
            else:
                results = [None] * total
                lock = threading.Lock()
                N = len(server_groups)
                done_count = [0]

                def worker(idx, sentence, group):
                    payload = build_payload(role_cfg, sentence)
                    audio, used = request_tts(group, payload)
                    with lock:
                        if audio:
                            results[idx] = audio
                            host = used.split("/")[2] if used else "?"
                            self._log_msg(f"  [OK] 句{idx+1}/{total} ({len(audio):,} bytes) ← {host}")
                        else:
                            self._log_msg(f"  [--] 句{idx+1}/{total} 失败")
                        done_count[0] += 1
                        self.after(0, lambda: self.progress_var.set(done_count[0] / total * 100))

                for batch_start in range(0, total, N):
                    if self._test_stop_flag: break
                    batch = sentences[batch_start:batch_start + N]
                    threads = [threading.Thread(target=worker,
                                                args=(batch_start+j, s, server_groups[j % N]))
                               for j, s in enumerate(batch)]
                    for t in threads: t.start()
                    for t in threads: t.join()

                for i, s in enumerate(sentences):
                    if results[i] is None and not self._test_stop_flag:
                        self._log_msg(f"  [重试] 句{i+1} 换服务器...")
                        fb = server_groups[(i+1) % N]
                        audio, used = request_tts(fb, build_payload(role_cfg, s))
                        if audio:
                            results[i] = audio
                            self._log_msg(f"  [OK] 句{i+1} 重试成功")
                        else:
                            self._log_msg(f"  [--] 句{i+1} 重试失败")

                valid = [r for r in results if r is not None]
                wav_data = merge_wav_bytes(valid) if valid else None

        # ── 保存 & 播放 ──────────────────────────────────────
        if not wav_data:
            self._log_msg("[错误] 无有效音频"); self._test_done(); return

        audio_dir = cfg.get("audio_dir", ".")
        os.makedirs(audio_dir, exist_ok=True)
        safe = re.sub(r'[\\/:*?"<>|\s]', '', text)[:20]
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        fname = f"{role_name}-{safe}-{ts}.wav"
        out_path = os.path.join(audio_dir, fname)
        with open(out_path, "wb") as fp:
            fp.write(wav_data)

        with wave.open(io.BytesIO(wav_data), 'rb') as wf:
            duration = wf.getnframes() / wf.getframerate()

        t_gen = (datetime.now() - t_start).total_seconds()
        self._log_msg(f"[完成] 耗时 {t_gen:.2f}s | 时长 {duration:.2f}s"
                      + (f" | 加速比 {duration/t_gen:.1f}x" if t_gen > 0 else ""))
        self._log_msg(f"[保存] {fname}")
        self.after(0, lambda: self.progress_var.set(100))

        try:
            play_wav(out_path)
        except Exception as e:
            self._log_msg(f"[播放] 失败: {e}")

        self._test_done()

    def _test_done(self):
        self.after(0, lambda: self.btn_play.config(state="normal"))

    def _log_msg(self, msg):
        def _do():
            self.log_box.config(state="normal")
            self.log_box.insert("end", msg + "\n")
            self.log_box.see("end")
            self.log_box.config(state="disabled")
        self.after(0, _do)

    def _log_clear(self):
        self.log_box.config(state="normal")
        self.log_box.delete("1.0", "end")
        self.log_box.config(state="disabled")

    # ════════════════════════════════════════════════
    #  工具
    # ════════════════════════════════════════════════
    def _browse_dir(self, var):
        path = filedialog.askdirectory(initialdir=var.get() or "/")
        if path: var.set(path)

    def _browse_file(self, var):
        path = filedialog.askopenfilename(filetypes=[("WAV文件", "*.wav"), ("所有文件", "*.*")])
        if path: var.set(path)

    def _collect_global(self):
        self.cfg["audio_dir"] = self.v_audio_dir.get().strip()
        self.cfg["parallel_threshold"] = self.v_threshold.get()
        self.cfg["mode"] = self.v_mode.get()
        self.cfg["client"] = {
            "proxy_url": self.v_client_proxy_url.get().strip(),
        }
        self.cfg["proxy"] = {
            "enabled":          bool(self._proxy and self._proxy.running),
            "port":             self.v_proxy_port.get(),
            "tts_port":         self.v_tts_port.get(),
            "tts_port_enabled": self.v_tts_port_enabled.get(),
            "auto_start":       self.v_proxy_auto.get(),
            "debug_mode":       self.v_proxy_debug.get(),
        }

    def _save(self):
        self._collect_global()
        save_config(self.cfg)
        # 同步热重载代理后端
        if self._proxy and self._proxy.running:
            self._proxy.reload_backends()
            try:
                self._proxy_refresh_backends()
            except Exception:
                pass
        messagebox.showinfo("保存成功", f"配置已保存到：\n{CONFIG_PATH}")

    def _export(self):
        self._collect_global()
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON文件", "*.json"), ("所有文件", "*.*")],
            initialfile="tts_config_export.json"
        )
        if path:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=2)
            messagebox.showinfo("导出成功", f"已导出到：\n{path}")

    def _import(self):
        path = filedialog.askopenfilename(
            filetypes=[("JSON文件", "*.json"), ("所有文件", "*.*")]
        )
        if not path: return
        try:
            with open(path, "r", encoding="utf-8") as f:
                new_cfg = json.load(f)
            self.cfg.update(new_cfg)
            # 刷新所有 UI
            self.v_audio_dir.set(self.cfg.get("audio_dir", ""))
            self.v_threshold.set(self.cfg.get("parallel_threshold", 4))
            self._refresh_role_list()
            self._refresh_server_tree()
            messagebox.showinfo("导入成功", f"已从以下文件导入配置：\n{path}")
        except Exception as e:
            messagebox.showerror("导入失败", str(e))

    def _on_close(self):
        if messagebox.askyesno("退出", "保存配置后退出？"):
            self._collect_global()
            save_config(self.cfg)
        if self._proxy and self._proxy.running:
            self._proxy.stop()
        self.destroy()

# ════════════════════════════════════════════════════════
if __name__ == "__main__":
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    app = TTSConfigApp()
    app.mainloop()
