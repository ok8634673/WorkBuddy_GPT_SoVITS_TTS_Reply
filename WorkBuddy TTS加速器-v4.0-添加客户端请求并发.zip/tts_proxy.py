"""
TTS 代理服务器 (tts_proxy.py)
────────────────────────────────────────────
监听本地端口，接收标准 GPT-SoVITS /tts 请求。

【智能加速模式】
  - 接收完整文本请求
  - 自动拆句 → 多台服务器并发合成
  - 按序合并 WAV → 返回完整音频
  - 多客户端同时请求时，各自独立并发，充分利用所有服务器

【兼容模式】（透传，当请求已是单句时）
  - Round-robin 轮询负载均衡
  - 自动跳过禁用服务器
  - 单台失败自动切换下一台

用法：
  python tts_proxy.py [--port 9882] [--config tts_gui_config.json]
"""

import json
import os
import sys
import re
import io
import wave
import time
import threading
import urllib.request
import urllib.error
import itertools
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime

# ── 强制 UTF-8 输出 ──────────────────────────────────────
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tts_gui_config.json")


# ════════════════════════════════════════════════════════
#  工具函数
# ════════════════════════════════════════════════════════

def split_sentences(text: str) -> list[str]:
    """智能分句，与 tts_gui.py 保持一致"""
    if not text.strip():
        return []
    parts = re.split(r'(?<=[。！？…～\!\?])', text)
    parts = [p.strip() for p in parts if p.strip()]
    merged = []
    buf = ""
    for p in parts:
        buf += p
        if len(buf) >= 8:
            merged.append(buf)
            buf = ""
    if buf:
        if merged:
            merged[-1] += buf
        else:
            merged.append(buf)
    result = []
    for s in merged:
        if len(s) > 50:
            subs = re.split(r'(?<=[，,；;、])', s)
            subs = [x.strip() for x in subs if x.strip()]
            sub_buf = ""
            for sub in subs:
                sub_buf += sub
                if len(sub_buf) >= 15:
                    result.append(sub_buf)
                    sub_buf = ""
            if sub_buf:
                if result:
                    result[-1] += sub_buf
                else:
                    result.append(sub_buf)
        else:
            result.append(s)
    return result if result else [text]


def merge_wav_bytes(wav_list: list[bytes]) -> bytes | None:
    """将多段 WAV 字节流按顺序合并"""
    if not wav_list:
        return None
    if len(wav_list) == 1:
        return wav_list[0]
    frames_list = []
    params = None
    for wb in wav_list:
        try:
            with wave.open(io.BytesIO(wb), 'rb') as wf:
                if params is None:
                    params = wf.getparams()
                frames_list.append(wf.readframes(wf.getnframes()))
        except Exception:
            pass
    if not frames_list or params is None:
        return None
    out = io.BytesIO()
    with wave.open(out, 'wb') as wf:
        wf.setparams(params)
        for f in frames_list:
            wf.writeframes(f)
    return out.getvalue()


def load_backends(config_path=CONFIG_PATH) -> list[list[str]]:
    """
    从配置文件读取后端，返回分组列表（每组为一台物理机器的所有IP）。
    只返回 enabled 的组和IP。
    """
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        groups = []
        for grp in cfg.get("server_groups", []):
            if not grp.get("enabled", True):
                continue
            urls = []
            for u in grp.get("urls", []):
                url = u["url"] if isinstance(u, dict) else u
                en  = u.get("enabled", True) if isinstance(u, dict) else True
                if en:
                    urls.append(url)
            if urls:
                groups.append(urls)
        return groups
    except Exception:
        return []


def load_roles(config_path=CONFIG_PATH) -> dict:
    """从配置文件读取角色配置"""
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        return cfg.get("roles", {})
    except Exception:
        return {}


# ════════════════════════════════════════════════════════
#  全局状态
# ════════════════════════════════════════════════════════

class ProxyState:
    """代理服务全局状态，供 HTTPHandler 共享"""
    def __init__(self):
        self.server_groups: list[list[str]] = []   # 按机器分组
        self.lock = threading.Lock()
        self._rr_group_idx = 0     # 全局 round-robin 组索引（跨请求共享！）
        self.total_req  = 0
        self.total_ok   = 0
        self.total_fail = 0
        self.log_cb   = None
        self.stats_cb = None
        # 每组当前并发数（用于最小负载调度）
        self._group_active: list[int] = []

    def reload(self, config_path=CONFIG_PATH):
        groups = load_backends(config_path)
        with self.lock:
            self.server_groups = groups
            self._rr_group_idx = 0
            self._group_active = [0] * len(groups)
        flat = [u for g in groups for u in g]
        self._log(f"[配置] 已加载 {len(groups)} 组 / {len(flat)} 个后端")
        for i, g in enumerate(groups):
            self._log(f"  组{i+1}: {g}")

    @property
    def all_backends_flat(self) -> list[str]:
        """所有后端展平列表"""
        with self.lock:
            return [u for g in self.server_groups for u in g]

    def next_group_rr(self) -> list[str] | None:
        """Round-robin 取下一个机器组（全局状态，跨请求）"""
        with self.lock:
            if not self.server_groups:
                return None
            g = self.server_groups[self._rr_group_idx % len(self.server_groups)]
            self._rr_group_idx += 1
            return g

    def alloc_groups_for_sentences(self, n_sentences: int) -> list[int]:
        """
        为 n_sentences 个句子分配组索引，保证：
        1. 句子尽量分散到不同组（利用所有机器）
        2. 基于全局 RR 偏移，跨请求错开，避免多客户端撞机
        返回每个句子应使用的 group_idx 列表
        """
        with self.lock:
            if not self.server_groups:
                return [0] * n_sentences
            n_groups = len(self.server_groups)
            base = self._rr_group_idx  # 本次请求的起始偏移
            self._rr_group_idx += n_sentences  # 全局偏移推进，下次请求会错开
            return [(base + i) % n_groups for i in range(n_sentences)]

    def _log(self, msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}"
        print(line, flush=True)
        if self.log_cb:
            try:
                self.log_cb(line)
            except Exception:
                pass

    def _update_stats(self):
        if self.stats_cb:
            try:
                self.stats_cb(self.total_req, self.total_ok, self.total_fail)
            except Exception:
                pass

    def log(self, msg):
        self._log(msg)

    def record_ok(self):
        self.total_ok += 1
        self._update_stats()

    def record_fail(self):
        self.total_fail += 1
        self._update_stats()

    def record_req(self):
        self.total_req += 1
        self._update_stats()


# 全局状态单例
_state = ProxyState()


# ════════════════════════════════════════════════════════
#  核心：并发合成引擎
# ════════════════════════════════════════════════════════

def _request_single(group_urls: list[str], payload: dict, timeout=90) -> tuple[bytes | None, str | None]:
    """向一组（同台机器的多IP）发请求，组内自动切换"""
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    for url in group_urls:
        try:
            req = urllib.request.Request(
                url, data=data,
                headers={"Content-Type": "application/json"}
            )
            r = urllib.request.urlopen(req, timeout=timeout)
            audio = r.read()
            if len(audio) > 100:
                return audio, url
        except urllib.error.HTTPError as e:
            err = e.read(100).decode(errors="replace")
            _state.log(f"[HTTP {e.code}] {url}  {err[:60]}")
            if 400 <= e.code < 500:
                return None, None   # 4xx 参数错误，不重试
        except Exception as e:
            _state.log(f"[网络失败] {url}  {type(e).__name__}: {e}")
    return None, None


def synthesize_parallel(payload_base: dict) -> tuple[bytes | None, str]:
    """
    智能并发合成：
      1. 从请求体提取 text，执行智能分句
      2. 无论几句，都基于全局 RR 偏移分配组，保证：
         - 单句请求：每次分配到不同组（多客户端轮流用不同机器）
         - 多句请求：各句并发分配到不同机器组
      3. 按序合并 WAV 返回
    返回 (wav_bytes, log_msg)
    """
    text = payload_base.get("text", "").strip()
    if not text:
        return None, "[错误] 请求体缺少 text 字段"

    with _state.lock:
        groups = list(_state.server_groups)

    if not groups:
        return None, "[错误] 无可用后端服务器"

    n_groups = len(groups)
    sentences = split_sentences(text)
    total = len(sentences)

    _state.log(f"[合成] {total}句 / {n_groups}组后端  文本: {text[:30]}{'…' if len(text)>30 else ''}")

    # 为每个句子分配组索引（全局 RR，跨请求错开）
    group_assignments = _state.alloc_groups_for_sentences(total)

    results: list[bytes | None] = [None] * total
    used_backends: list[str] = [""] * total
    lock = threading.Lock()

    def worker(idx: int, sentence: str, grp_idx: int):
        payload = dict(payload_base)
        payload["text"] = sentence
        payload["text_split_method"] = "cut0"   # 单句，禁止 GPT-SoVITS 内部再分
        t0 = time.time()
        group = groups[grp_idx]
        audio, used = _request_single(group, payload)
        elapsed = time.time() - t0
        with lock:
            if audio:
                results[idx] = audio
                used_backends[idx] = used or ""
                _state.log(f"[OK] 句{idx+1}/{total} {len(audio):,}B {elapsed:.2f}s ← {used}")
            else:
                _state.log(f"[--] 句{idx+1}/{total} 失败 ({elapsed:.2f}s)")

    # 全部句子同时并发（不再分批，让各机器真正同时工作）
    threads = [
        threading.Thread(target=worker, args=(i, s, group_assignments[i]), daemon=True)
        for i, s in enumerate(sentences)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # 失败重试（换下一组）
    for i, s in enumerate(sentences):
        if results[i] is None:
            _state.log(f"[重试] 句{i+1} 换组重试...")
            retry_grp = (group_assignments[i] + 1) % n_groups
            payload = dict(payload_base)
            payload["text"] = s
            payload["text_split_method"] = "cut0"
            audio, used = _request_single(groups[retry_grp], payload)
            if audio:
                results[i] = audio
                used_backends[i] = used or ""
                _state.log(f"[OK] 句{i+1} 重试成功 ← {used}")
            else:
                _state.log(f"[--] 句{i+1} 重试仍失败，跳过")

    valid = [r for r in results if r is not None]
    if not valid:
        return None, "[失败] 所有句子合成失败"

    if total == 1:
        # 单句直接返回，不需要合并
        return valid[0], used_backends[0] or ""

    wav_data = merge_wav_bytes(valid)
    if not wav_data:
        return None, "[失败] WAV 合并失败"

    backends_used = list(dict.fromkeys(b for b in used_backends if b))
    return wav_data, f"并发{total}句，后端: {backends_used}"


# ════════════════════════════════════════════════════════
#  HTTP 处理器
# ════════════════════════════════════════════════════════

class TTSProxyHandler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass  # 屏蔽默认 access log

    def do_GET(self):
        if self.path == "/status":
            self._send_status()
        elif self.path == "/backends":
            self._send_backends()
        elif self.path in ("/", "/health"):
            self._respond(200, b'{"status":"ok"}')
        else:
            self._not_found()

    def do_POST(self):
        if self.path.rstrip("/") in ("/tts",):
            self._handle_tts()
        else:
            self._not_found()

    def _handle_tts(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length) if length > 0 else b""

        _state.record_req()

        # 解析请求体
        try:
            payload = json.loads(body.decode("utf-8"))
        except Exception:
            _state.record_fail()
            self._respond(400, b'{"error":"invalid JSON body"}')
            return

        t0 = time.time()
        wav_data, info = synthesize_parallel(payload)
        elapsed = time.time() - t0

        if wav_data is None:
            _state.log(f"[错误] {info}  ({elapsed:.2f}s)")
            _state.record_fail()
            self._respond(502, json.dumps({"error": info}).encode())
            return

        _state.log(f"[完成] {len(wav_data):,}B  {elapsed:.2f}s  {info}")
        _state.record_ok()

        # HTTP 响应头只能用 latin-1，把非 ASCII 字符替换掉
        safe_info = info.encode('ascii', errors='replace').decode('ascii')[:120]

        self.send_response(200)
        self.send_header("Content-Type", "audio/wav")
        self.send_header("Content-Length", str(len(wav_data)))
        self.send_header("X-Backend", safe_info)
        self.send_header("X-Elapsed", f"{elapsed:.2f}s")
        self.end_headers()
        self.wfile.write(wav_data)

    def _send_status(self):
        flat = _state.all_backends_flat
        data = json.dumps({
            "running": True,
            "groups":  len(_state.server_groups),
            "backends": flat,
            "total_req":  _state.total_req,
            "total_ok":   _state.total_ok,
            "total_fail": _state.total_fail,
        }, ensure_ascii=False).encode()
        self._respond(200, data, "application/json")

    def _send_backends(self):
        data = json.dumps(_state.all_backends_flat, ensure_ascii=False).encode()
        self._respond(200, data, "application/json")

    def _not_found(self):
        self._respond(404, b'{"error":"not found"}')

    def _respond(self, code, body, ct="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


# ════════════════════════════════════════════════════════
#  TTSProxyServer 封装（供 GUI 嵌入）
# ════════════════════════════════════════════════════════

class TTSProxyServer:
    """
    可嵌入 GUI 的代理服务封装。

    用法：
        proxy = TTSProxyServer(port=9882, config_path=..., log_cb=..., stats_cb=...)
        proxy.start()
        ...
        proxy.reload_backends()
        proxy.stop()
    """

    def __init__(self, port=9882, config_path=CONFIG_PATH,
                 log_cb=None, stats_cb=None):
        self.port = port
        self.config_path = config_path
        self._server: HTTPServer | None = None
        self._thread: threading.Thread | None = None
        self.running = False
        _state.log_cb   = log_cb
        _state.stats_cb = stats_cb

    def reload_backends(self):
        _state.reload(self.config_path)

    @property
    def backends(self) -> list[str]:
        return _state.all_backends_flat

    @property
    def groups(self) -> list[list[str]]:
        return list(_state.server_groups)

    def start(self):
        if self.running:
            return
        _state.reload(self.config_path)
        _state.total_req = _state.total_ok = _state.total_fail = 0

        try:
            self._server = HTTPServer(("0.0.0.0", self.port), TTSProxyHandler)
        except OSError as e:
            _state.log(f"[错误] 端口 {self.port} 无法绑定: {e}")
            raise

        self.running = True
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()
        _state.log(f"[启动] 代理服务监听 0.0.0.0:{self.port}  /tts")
        _state.log(f"[提示] 客户端将 TTS 地址改为 http://本机IP:{self.port}/tts 即可")
        _state.log(f"[模式] 智能并发加速 — 自动拆句 → 多服务器并发 → 合并返回")

    def _serve(self):
        try:
            self._server.serve_forever()
        except Exception:
            pass

    def stop(self):
        if not self.running:
            return
        self.running = False
        if self._server:
            self._server.shutdown()
            self._server = None
        _state.log("[停止] 代理服务已关闭")

    @property
    def local_url(self):
        return f"http://127.0.0.1:{self.port}/tts"


# ════════════════════════════════════════════════════════
#  命令行独立运行
# ════════════════════════════════════════════════════════
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="TTS 代理服务器（智能并发加速版）")
    parser.add_argument("--port",   type=int, default=9882)
    parser.add_argument("--config", type=str, default=CONFIG_PATH)
    args = parser.parse_args()

    proxy = TTSProxyServer(port=args.port, config_path=args.config)
    try:
        proxy.start()
        print(f"代理已启动，按 Ctrl+C 停止。", flush=True)
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        proxy.stop()
        print("已退出。")
