"""
speak.py — WorkBuddy AI 专用静默启动器
=====================================
调用方式：python G:\\WorkBuddy\\TTS加速器\\speak.py <角色> <文本>
- 内部调用 tts_reply.py，日志写 speak_log.txt，聊天窗口静默
- 完成后写 speak_result.txt（耗时,加速比）
"""

import sys
import os
import io
import re
from datetime import datetime

# ── 路径：以本脚本所在目录为基准，不依赖工作目录 ──────────────────
_HERE       = os.path.dirname(os.path.abspath(__file__))
LOG_FILE    = os.path.join(_HERE, "speak_log.txt")
RESULT_FILE = os.path.join(_HERE, "speak_result.txt")

# 把 TTS加速器目录加入 sys.path，确保能 import tts_reply
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

# 切换工作目录到 TTS加速器，保证相对路径（参考音频等）正确解析
os.chdir(_HERE)


def speak(role: str, text: str) -> None:
    """直接 import tts_reply 模块调用，无子进程无弹窗，stdout 重定向到日志文件。"""
    import tts_reply as _tts

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    preview   = text[:40] + ("..." if len(text) > 40 else "")

    # 把 tts_reply 的所有 print 输出重定向到日志文件，聊天窗口保持静默
    with open(LOG_FILE, "w", encoding="utf-8") as log:
        log.write(f"[{timestamp}] {role}: {preview}\n")
        log.flush()
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = log
        sys.stderr = log
        try:
            _tts.tts_reply(role, text)
        except Exception as e:
            log.write(f"[speak] 异常: {e}\n")
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

    # 从日志提取耗时和加速比，写到 speak_result.txt
    try:
        with open(LOG_FILE, encoding="utf-8") as f:
            log_text = f.read()
        m = re.search(r'\[完成\] 生成耗时 ([\d.]+)s \| 音频时长 [\d.]+s \| 加速比 ([\d.]+)x', log_text)
        summary = f"{m.group(1)}s,{m.group(2)}x" if m else "unknown"
    except Exception:
        summary = "unknown"

    with open(RESULT_FILE, "w", encoding="utf-8") as f:
        f.write(summary + "\n")

    # 把摘要输出到 stdout，供调用方直接读取（不需要再 type 文件）
    if summary != "unknown":
        t, r = summary.split(",")
        print(f"（生成耗时 {t}，加速比 {r}）")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法: python speak.py <角色> <文本>")
        print("示例: python speak.py 可莉 \"旅行者你好！\"")
        sys.exit(1)

    _role = sys.argv[1]
    _text = " ".join(sys.argv[2:])
    speak(_role, _text)
