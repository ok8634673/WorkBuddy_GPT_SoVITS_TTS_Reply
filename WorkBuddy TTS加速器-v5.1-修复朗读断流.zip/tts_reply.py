"""
WorkBuddy TTS 并行加速回复工具
策略：智能分句 → 两台服务器并发合成 → 按序合并 WAV → 播放
用法：python tts_reply.py "角色名" "回复文本"
"""
import sys
import os
import re
import io
import json
import wave
import winsound
import urllib.request
import urllib.error
import urllib.parse
import threading
import socket
from datetime import datetime

# ── 自动切换工作目录到脚本所在目录，兼容任意调用路径和中文路径 ──
_HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(_HERE)

# 强制 stdout 使用 utf-8，避免 Windows GBK 编码报错
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8')

AUDIO_DIR   = r"G:\WorkBuddy\generated_audio"
RESULT_FILE = os.path.join(_HERE, "speak_result.txt")

# ── 服务器分组（每组为一台物理机器，组内任一IP可用即可）──
SERVER_GROUPS = [
    # 笔记本（首选）
    [
        "http://192.168.28.3:9880/tts",
        "http://192.168.31.5:9880/tts",
        "http://192.168.28.7:9880/tts",
    ],
    # 华硕主机（备选）
    [
        "http://192.168.31.177:9880/tts",
        "http://192.168.28.2:9880/tts",
        "http://192.168.28.127:9880/tts",
    ],
]

# ── 角色配置 ──
ROLES = {
    "可莉": {
        "ref_audio_path": "audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
        "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
        "prompt_lang": "zh",
        "text_lang": "zh",
        "text_split_method": "cut5",
    },
    "瑶瑶": {
        "ref_audio_path": "audio/yaoyao-甘雨姐姐，你没事吧？要不要喝点水，或者吃点别的什么调节一下？.wav",
        "prompt_text": "甘雨姐姐，你没事吧？要不要喝点水，或者吃点别的什么调节一下？",
        "prompt_lang": "zh",
        "text_lang": "zh",
        "text_split_method": "cut5",
    },
    "纳西妲": {
        "ref_audio_path": "audio/nahida-如果是说踏鞴砂那个神秘事件与倾奇者之类的.wav",
        "prompt_text": "如果是说踏鞴砂那个神秘事件与倾奇者之类的",
        "prompt_lang": "zh",
        "text_lang": "zh",
        "text_split_method": "cut5",
        "speed_factor": 0.85,
    },
}

# ── 智能分句 ──
def split_sentences(text):
    """
    按中文标点智能分句，保证语序完整、语义完整。
    规则：
      1. 按句末标点（。！？…～）切分
      2. 短句（<8字）尽量与下一句合并，避免碎片化
      3. 长句（>40字）按逗号、分号二次切分
      4. 最终每组不超过50字
    """
    if not text.strip():
        return []

    # 第一步：按句末标点切分
    parts = re.split(r'(?<=[。！？…～\!\?])', text)
    parts = [p.strip() for p in parts if p.strip()]

    # 第二步：短句合并（小于8字的短句合并到下一句）
    merged = []
    buf = ""
    for p in parts:
        buf += p
        if len(buf) >= 8:
            merged.append(buf)
            buf = ""
    if buf:
        if merged:
            merged[-1] += buf
        else:
            merged.append(buf)

    # 第三步：超长句按逗号/分号二次切分
    result = []
    for s in merged:
        if len(s) > 50:
            subs = re.split(r'(?<=[，,；;、])', s)
            subs = [x.strip() for x in subs if x.strip()]
            # 再次合并过短的子句
            sub_buf = ""
            for sub in subs:
                sub_buf += sub
                if len(sub_buf) >= 15:
                    result.append(sub_buf)
                    sub_buf = ""
            if sub_buf:
                if result:
                    result[-1] += sub_buf
                else:
                    result.append(sub_buf)
        else:
            result.append(s)

    return result if result else [text]

# ── 构建 TTS 请求体 ──
def build_payload(role, text, server_url=None):
    cfg = ROLES.get(role, ROLES["可莉"])
    # 强制确保 text_lang 不为 None，默认使用 "zh"
    # 也把 "auto" 转换为 "zh"，因为服务器可能不支持 auto
    text_lang = cfg.get("text_lang") or "zh"
    if text_lang == "auto":
        text_lang = "zh"
    
    # 默认使用笔记本首选 IP
    if server_url is None:
        server_url = "http://192.168.28.3:9880/tts"
    
    payload = {
        "type": "gpt_sovits_v2",
        "text": text,
        "text_lang": text_lang,
        "ref_audio_path": cfg["ref_audio_path"],
        "prompt_text": cfg["prompt_text"],
        "prompt_lang": cfg["prompt_lang"],
        "url": server_url,
        "output_dir": "tmp/",
        "top_k": 5,
        "top_p": 1,
        "temperature": 1,
        "text_split_method": cfg.get("text_split_method", "cut0"),   # 已手动分句，不再二次切分
        "batch_size": 1,
        "batch_threshold": 0.75,
        "split_bucket": True,
        "return_fragment": False,
        "speed_factor": cfg.get("speed_factor", 1.0),
        "streaming_mode": False,
        "seed": -1,
        "parallel_infer": True,
        "repetition_penalty": 1.35,
        "aux_ref_audio_paths": []
    }
    
    return payload

# ── 快速健康检测（TCP connect，3秒超时） ──
def is_group_alive(server_group, timeout=3):
    """尝试TCP连接组内任一IP，能连上就返回True"""
    for url in server_group:
        try:
            parsed = urllib.parse.urlparse(url)
            host = parsed.hostname
            port = parsed.port or 9880
            sock = socket.create_connection((host, port), timeout=timeout)
            sock.close()
            return True
        except Exception:
            continue
    return False

# ── 向单台服务器组发请求（组内自动切换，支持重试） ──
def request_tts(server_group, payload, timeout=90, retries=2):
    """
    请求 TTS 合成，支持自动重试和故障转移
    - 优先使用第一个服务器
    - 如果失败，自动尝试组内其他服务器
    - 最后可选全局重试机制
    """
    data = json.dumps(payload).encode("utf-8")
    last_error = None
    
    # 单次组内尝试
    for attempt in range(retries + 1):
        if attempt > 0:
            print(f"    [重试 {attempt}/{retries}] 重新请求服务器组...")
        
        for url in server_group:
            try:
                req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
                r = urllib.request.urlopen(req, timeout=timeout)
                audio = r.read()
                if len(audio) > 100:
                    return audio, url
                else:
                    print(f"    [!] {url} 返回数据过小 ({len(audio)} bytes)")
                    last_error = f"数据过小"
            except urllib.error.HTTPError as e:
                try:
                    err = e.read().decode(errors='replace')[:80]
                except:
                    err = str(e.code)
                print(f"    [!] {url} HTTP {e.code}: {err}")
                last_error = f"HTTP {e.code}"
            except urllib.error.URLError as e:
                print(f"    [!] {url} 连接失败: {type(e.reason).__name__}")
                last_error = f"连接失败: {type(e.reason).__name__}"
            except socket.timeout:
                print(f"    [!] {url} 请求超时 ({timeout}s)")
                last_error = "请求超时"
            except Exception as e:
                print(f"    [!] {url} {type(e).__name__}: {e}")
                last_error = f"{type(e).__name__}: {e}"
    
    return None, last_error

# ── WAV 字节流合并（保持语序） ──
def merge_wav_bytes(wav_list):
    """将多段 WAV 字节流按顺序合并为一个完整 WAV，零间隙拼接"""
    if not wav_list:
        return None
    if len(wav_list) == 1:
        return wav_list[0]

    frames_list = []
    params = None
    for wav_bytes in wav_list:
        try:
            with wave.open(io.BytesIO(wav_bytes), 'rb') as wf:
                if params is None:
                    params = wf.getparams()
                frames_list.append(wf.readframes(wf.getnframes()))
        except Exception as e:
            print(f"  [!] WAV解析失败: {e}")
            continue

    if not frames_list or params is None:
        return None

    out_buf = io.BytesIO()
    with wave.open(out_buf, 'wb') as wf:
        wf.setparams(params)
        for frames in frames_list:
            wf.writeframes(frames)
    return out_buf.getvalue()

# ── 文件命名 ──
def make_filename(role, text):
    safe = re.sub(r'[\\/:*?"<>|\s]', '', text)[:20]
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"{role}-{safe}-{ts}.wav"

# ── 主函数 ──
def tts_reply(role, text):
    print(f"\n{'='*55}")
    print(f"[{role}] {text}")
    print(f"{'='*55}")

    sentences = split_sentences(text)
    total = len(sentences)
    print(f"[分句] 共 {total} 句: {sentences}")

    if total == 0:
        return

    t_start = datetime.now()

    # 单句：串行
    if total <= 1:
        print(f"[合成] 串行模式（{total}句）")
        all_servers = SERVER_GROUPS[0] + SERVER_GROUPS[1]
        wav_list = []
        failed_count = 0
        for i, s in enumerate(sentences):
            payload = build_payload(role, s, all_servers[0])
            audio, info = request_tts(all_servers, payload, retries=2)
            if audio:
                wav_list.append(audio)
                print(f"  [✓] 句{i+1}/{total} 成功 ({len(audio)} bytes) <- {info.split('/')[2] if '/' in info else info}")
            else:
                failed_count += 1
                print(f"  [✗] 句{i+1}/{total} 失败: {info}")
        
        if not wav_list:
            print("[错误] 所有片段合成失败！")
            return
        
        if failed_count > 0:
            print(f"[警告] {failed_count}/{total} 句合成失败，音频将不完整！")
        
        wav_data = merge_wav_bytes(wav_list) if len(wav_list) > 1 else wav_list[0]
    else:
        # 2句及以上：并发模式
        # 先做健康检测，过滤掉不在线的服务器组
        print(f"[健康检测] 检测 {len(SERVER_GROUPS)} 个服务器组...")
        alive_groups = []
        for i, group in enumerate(SERVER_GROUPS):
            ok = is_group_alive(group)
            print(f"  组{i+1}: {'在线 ✓' if ok else '离线 ✗'} ({group[0].split('/')[2]}...)")
            if ok:
                alive_groups.append(group)

        if not alive_groups:
            print("[错误] 所有服务器离线，无法合成")
            return

        N_MACHINES = len(alive_groups)
        print(f"[合成] 并行模式（{total}句 × {N_MACHINES}台在线服务器）")
        results = [None] * total
        lock = threading.Lock()

        def worker(idx, sentence, group, attempt=1):
            payload = build_payload(role, sentence, group[0])
            audio, info = request_tts(group, payload, retries=1)
            with lock:
                if audio:
                    results[idx] = audio
                    print(f"  [✓] 句{idx+1}/{total} 成功 ({len(audio)} bytes) <- {info.split('/')[2] if '/' in info else info}")
                else:
                    print(f"  [✗] 句{idx+1}/{total} 失败 (第{attempt}次): {info}")

        # 按轮次分批处理，每轮最多 N_MACHINES 句并行
        for batch_start in range(0, total, N_MACHINES):
            batch = sentences[batch_start:batch_start + N_MACHINES]
            threads = []
            for j, s in enumerate(batch):
                idx = batch_start + j
                group = alive_groups[j % N_MACHINES]
                t = threading.Thread(target=worker, args=(idx, s, group, 1))
                threads.append(t)
                t.start()
            for t in threads:
                t.join()

        # 失败的句子换另一台服务器重试（第二次尝试）
        failed_indices = [i for i, r in enumerate(results) if r is None]
        if failed_indices and len(alive_groups) > 1:
            print(f"[重试] {len(failed_indices)} 个失败句子尝试换服务器...")
            retry_threads = []
            for i in failed_indices:
                s = sentences[i]
                fallback_group = alive_groups[(i + 1) % N_MACHINES]
                t = threading.Thread(target=worker, args=(i, s, fallback_group, 2))
                retry_threads.append(t)
                t.start()
            for t in retry_threads:
                t.join()

        # 统计最终结果
        valid = [r for r in results if r is not None]
        still_failed = len([r for r in results if r is None])
        
        if still_failed > 0:
            print(f"[警告] {still_failed}/{total} 句仍然失败，音频将不完整！")
        
        if not valid:
            print("[错误] 全部片段合成失败")
            return

        wav_data = merge_wav_bytes(valid)
        if not wav_data:
            print("[错误] WAV 合并失败")
            return

    t_gen = (datetime.now() - t_start).total_seconds()

    # 保存文件
    os.makedirs(AUDIO_DIR, exist_ok=True)
    out_path = os.path.join(AUDIO_DIR, make_filename(role, text))
    with open(out_path, "wb") as f:
        f.write(wav_data)

    # 获取时长
    with wave.open(io.BytesIO(wav_data), 'rb') as wf:
        duration = wf.getnframes() / wf.getframerate()

    print(f"[完成] 生成耗时 {t_gen:.2f}s | 音频时长 {duration:.2f}s | 加速比 {duration/t_gen:.1f}x")
    print(f"[保存] {os.path.basename(out_path)}")

    # 写摘要文件，供 AI 调用时快速读取结果
    try:
        with open(RESULT_FILE, "w", encoding="utf-8") as f:
            f.write(f"{t_gen:.2f}s,{duration/t_gen:.1f}x\n")
    except Exception:
        pass

    # 播放
    winsound.PlaySound(out_path, winsound.SND_FILENAME)

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--verbose"]
    verbose = "--verbose" in sys.argv

    if len(args) < 2:
        print("用法: python tts_reply.py <角色名> <文本> [--verbose]")
        sys.exit(1)

    if verbose:
        # 详细模式：完整日志输出，适合调试
        tts_reply(args[0], args[1])
    else:
        # 默认静默模式：日志写文件，只输出一行摘要
        log_path = os.path.join(_HERE, "speak_log.txt")
        with open(log_path, "w", encoding="utf-8") as _log:
            _orig_stdout, _orig_stderr = sys.stdout, sys.stderr
            sys.stdout = _log
            sys.stderr = _log
            try:
                tts_reply(args[0], args[1])
            finally:
                sys.stdout = _orig_stdout
                sys.stderr = _orig_stderr
        try:
            with open(RESULT_FILE, encoding="utf-8") as f:
                t, r = f.read().strip().split(",")
            print(f"（生成耗时 {t}，加速比 {r}）")
        except Exception:
            pass
